class NumericalLSDRadixSorter:

    def __init__(self):

        self._record_extractor = None
        self._character_code_extractor = None

    def _natural_code_extractor(self,
                                record,
                                exponent):

        raw_number = self._record_extractor(record)
        digit = abs(raw_number) // exponent % 10

        if raw_number <= 0:
            return 9 - digit
        else:
            return 9 + digit

    def _reverse_code_extractor(self,
                                record,
                                exponent):

        raw_number = self._record_extractor(record)
        digit = abs(raw_number) // exponent % 10

        if raw_number >= 0:
            return 9 - digit
        else:
            return 9 + digit

    def _counting_sort(self,
                       records,
                       initial_index,
                       terminal_index,
                       exponent):

        if initial_index >= terminal_index:
            return records

        range_size = 19

        number_to_count = [0] * range_size
        for record in records[initial_index: terminal_index + 1]:
            number = self._character_code_extractor(record, exponent)
            number_to_count[number] += 1

        for number in range(1, range_size):
            number_to_count[number] += number_to_count[number - 1]

        sorted_records = [None] * (terminal_index - initial_index + 1)
        for record in reversed(records[initial_index: terminal_index + 1]):
            number = self._character_code_extractor(record, exponent)
            number_to_count[number] -= 1
            sorted_index = number_to_count[number]
            sorted_records[sorted_index] = record

        records[initial_index: terminal_index + 1] = sorted_records

        return records

    def _radix_sort(self,
                    records):

        minimum_number = min(self._record_extractor(record)
                             for record in records)
        maximum_number = max(self._record_extractor(record)
                             for record in records)

        if minimum_number == maximum_number:
            return records

        maximum_absolute_number = max(abs(minimum_number),
                                      abs(maximum_number))

        exponent = 1
        while maximum_absolute_number // exponent > 0:
            records = self._counting_sort(records,
                                          0,
                                          len(records) - 1,
                                          exponent)
            exponent *= 10

        return records

    def sort(self,
             records,
             extractor=None,
             is_order_natural=True):

        if not records:
            return records

        if not callable(extractor):
            self._record_extractor = lambda value: value
        else:
            self._record_extractor = extractor

        if is_order_natural:
            self._character_code_extractor = self._natural_code_extractor
        else:
            self._character_code_extractor = self._reverse_code_extractor

        sorted_records = self._radix_sort(records)

        self._record_extractor = None
        self._character_code_extractor = None

        return sorted_records


def numerical_lsd_radix_sort(records,
                             extractor=None,
                             is_order_natural=True):

    lsd_radix_sorter = NumericalLSDRadixSorter()

    return lsd_radix_sorter.sort(records,
                                 extractor=extractor,
                                 is_order_natural=is_order_natural)


class RecursiveNumericalMSDRadixSorter:

    def __init__(self):

        self._record_extractor = None
        self._character_code_extractor = None

    def _natural_code_extractor(self,
                                record,
                                exponent):

        raw_number = self._record_extractor(record)
        digit = abs(raw_number) // exponent % 10

        if raw_number <= 0:
            return 9 - digit
        else:
            return 9 + digit

    def _reverse_code_extractor(self,
                                record,
                                exponent):

        raw_number = self._record_extractor(record)
        digit = abs(raw_number) // exponent % 10

        if raw_number >= 0:
            return 9 - digit
        else:
            return 9 + digit

    def _counting_sort(self,
                       records,
                       initial_index,
                       terminal_index,
                       exponent):

        if initial_index >= terminal_index:
            return records

        range_size = 19

        number_to_count = [0] * range_size
        for record in records[initial_index: terminal_index + 1]:
            number = self._character_code_extractor(record, exponent)
            number_to_count[number] += 1

        for number in range(1, range_size):
            number_to_count[number] += number_to_count[number - 1]

        sorted_records = [None] * (terminal_index - initial_index + 1)
        for record in reversed(records[initial_index: terminal_index + 1]):
            number = self._character_code_extractor(record, exponent)
            number_to_count[number] -= 1
            sorted_index = number_to_count[number]
            sorted_records[sorted_index] = record

        records[initial_index: terminal_index + 1] = sorted_records

        if exponent <= 1:
            return records

        for number in range(1, range_size):
            records = self._counting_sort(records,
                                          initial_index + number_to_count[number - 1],
                                          initial_index + number_to_count[number] - 1,
                                          exponent // 10)
        records = self._counting_sort(records,
                                      initial_index + number_to_count[range_size - 1],
                                      terminal_index,
                                      exponent // 10)

        return records

    def _radix_sort(self,
                    records):

        minimum_number = min(self._record_extractor(record)
                             for record in records)
        maximum_number = max(self._record_extractor(record)
                             for record in records)

        if minimum_number == maximum_number:
            return records

        maximum_absolute_number = max(abs(minimum_number),
                                      abs(maximum_number))

        exponent = 10 ** (len(str(maximum_absolute_number)) - 1)
        records = self._counting_sort(records,
                                      0,
                                      len(records) - 1,
                                      exponent)

        return records

    def sort(self,
             records,
             extractor=None,
             is_order_natural=True):

        if not records:
            return records

        if not callable(extractor):
            self._record_extractor = lambda value: value
        else:
            self._record_extractor = extractor

        if is_order_natural:
            self._character_code_extractor = self._natural_code_extractor
        else:
            self._character_code_extractor = self._reverse_code_extractor

        sorted_records = self._radix_sort(records)

        self._record_extractor = None
        self._character_code_extractor = None

        return sorted_records


def recursive_numerical_msd_radix_sort(records,
                                       extractor=None,
                                       is_order_natural=True):

    msd_radix_sorter = RecursiveNumericalMSDRadixSorter()

    return msd_radix_sorter.sort(records,
                                 extractor=extractor,
                                 is_order_natural=is_order_natural)


class IterativeNumericalMSDRadixSorter:

    def __init__(self):

        self._record_extractor = None
        self._character_code_extractor = None

    def _natural_code_extractor(self,
                                record,
                                exponent):

        raw_number = self._record_extractor(record)
        digit = abs(raw_number) // exponent % 10

        if raw_number <= 0:
            return 9 - digit
        else:
            return 9 + digit

    def _reverse_code_extractor(self,
                                record,
                                exponent):

        raw_number = self._record_extractor(record)
        digit = abs(raw_number) // exponent % 10

        if raw_number >= 0:
            return 9 - digit
        else:
            return 9 + digit

    def _counting_sort(self,
                       records,
                       exponent):

        range_size = 19

        stack = [(0, len(records) - 1, exponent)]

        while stack:

            initial_index, terminal_index, exponent = stack.pop()

            number_to_count = [0] * range_size
            for record in records[initial_index: terminal_index + 1]:
                number = self._character_code_extractor(record, exponent)
                number_to_count[number] += 1

            for number in range(1, range_size):
                number_to_count[number] += number_to_count[number - 1]

            sorted_records = [None] * (terminal_index - initial_index + 1)
            for record in reversed(records[initial_index: terminal_index + 1]):
                number = self._character_code_extractor(record, exponent)
                number_to_count[number] -= 1
                sorted_index = number_to_count[number]
                sorted_records[sorted_index] = record

            records[initial_index: terminal_index + 1] = sorted_records

            if exponent > 1:

                for number in range(1, range_size):
                    new_initial_index = initial_index + number_to_count[number - 1]
                    new_terminal_index = initial_index + number_to_count[number] - 1
                    new_exponent = exponent // 10
                    if new_initial_index < new_terminal_index:
                        stack.append((new_initial_index, new_terminal_index, new_exponent))

                new_initial_index = initial_index + number_to_count[range_size - 1]
                new_terminal_index = terminal_index
                new_exponent = exponent // 10
                if new_initial_index < new_terminal_index:
                    stack.append((new_initial_index, new_terminal_index, new_exponent))

        return records

    def _radix_sort(self,
                    records):

        minimum_number = min(self._record_extractor(record)
                             for record in records)
        maximum_number = max(self._record_extractor(record)
                             for record in records)

        if minimum_number == maximum_number:
            return records

        maximum_absolute_number = max(abs(minimum_number),
                                      abs(maximum_number))

        exponent = 10 ** (len(str(maximum_absolute_number)) - 1)
        records = self._counting_sort(records,
                                      exponent)

        return records

    def sort(self,
             records,
             extractor=None,
             is_order_natural=True):

        if not records:
            return records

        if not callable(extractor):
            self._record_extractor = lambda value: value
        else:
            self._record_extractor = extractor

        if is_order_natural:
            self._character_code_extractor = self._natural_code_extractor
        else:
            self._character_code_extractor = self._reverse_code_extractor

        sorted_records = self._radix_sort(records)

        self._record_extractor = None
        self._character_code_extractor = None

        return sorted_records


def iterative_numerical_msd_radix_sort(records,
                                       extractor=None,
                                       is_order_natural=True):

    msd_radix_sorter = IterativeNumericalMSDRadixSorter()

    return msd_radix_sorter.sort(records,
                                 extractor=extractor,
                                 is_order_natural=is_order_natural)
