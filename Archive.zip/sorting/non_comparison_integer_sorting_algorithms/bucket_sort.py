def bucket_sort(records,
                left_bound=None,
                right_bound=None,
                extractor=None,
                is_order_natural=True):

    if not records:
        return records

    if not callable(extractor):
        record_extractor = lambda value: value
    else:
        record_extractor = extractor

    if left_bound is None:
        minimum_key = min(record_extractor(record)
                          for record in records)
    else:
        minimum_key = left_bound
    if right_bound is None:
        maximum_key = max(record_extractor(record)
                          for record in records)
    else:
        maximum_key = right_bound

    if minimum_key == maximum_key:
        return records

    if is_order_natural:
        record_to_index = lambda record: record_extractor(record) - minimum_key
    else:
        record_to_index = lambda record: maximum_key - record_extractor(record)

    range_size = maximum_key - minimum_key + 1

    index_to_bucket = [list()
                       for _ in range(0, range_size)]

    for record in records:
        index = record_to_index(record)
        index_to_bucket[index].append(record)

    sorted_records = []
    for bucket in index_to_bucket:
        sorted_records.extend(bucket)

    return sorted_records
