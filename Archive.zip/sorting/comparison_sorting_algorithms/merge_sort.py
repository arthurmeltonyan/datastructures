class RecursiveMergeSorter:

    def __init__(self):

        self._record_extractor = None

    def _merge(self,
               left_records,
               right_records):

        left_index = 0
        right_index = 0
        records = []

        while left_index < len(left_records) and right_index < len(right_records):

            if self._record_extractor(left_records[left_index]) < self._record_extractor(right_records[right_index]):
                record = left_records[left_index]
                left_index += 1
            else:
                record = right_records[right_index]
                right_index += 1

            records.append(record)

        records.extend(left_records[left_index:])
        records.extend(right_records[right_index:])

        return records

    def _sort(self,
              records,
              left_index,
              right_index):

        if left_index >= right_index:
            return records[left_index: right_index + 1]

        midpoint = left_index + (right_index - left_index) // 2

        left_records = self._sort(records,
                                  left_index,
                                  midpoint)
        right_records = self._sort(records,
                                   midpoint + 1,
                                   right_index)

        return self._merge(left_records,
                           right_records)

    def sort(self,
             records,
             extractor=None,
             is_order_natural=True):

        if not records:
            return records

        if not callable(extractor) and is_order_natural:
            self._record_extractor = lambda record: record
        elif not callable(extractor):
            self._record_extractor = lambda record: -record
        elif is_order_natural:
            self._record_extractor = lambda record: extractor(record)
        else:
            self._record_extractor = lambda record: -extractor(record)

        return self._sort(records,
                          0,
                          len(records) - 1)


def recursive_merge_sort(records,
                         extractor=None,
                         is_order_natural=True):

    merge_sorter = RecursiveMergeSorter()

    return merge_sorter.sort(records,
                             extractor=extractor,
                             is_order_natural=is_order_natural)


class IterativeMergeSorter:

    def __init__(self):

        self._record_extractor = None

    def _merge(self,
               left_records,
               right_records):

        left_index = 0
        right_index = 0
        records = []

        while left_index < len(left_records) and right_index < len(right_records):

            if self._record_extractor(left_records[left_index]) < self._record_extractor(right_records[right_index]):
                record = left_records[left_index]
                left_index += 1
            else:
                record = right_records[right_index]
                right_index += 1

            records.append(record)

        records.extend(left_records[left_index:])
        records.extend(right_records[right_index:])

        return records

    def _sort(self,
              records):

        n = len(records)
        length = 1

        while length < n:

            left_begin_index = 0
            right_begin_index = length
            while right_begin_index + length < n:
                left_records = records[left_begin_index: left_begin_index + length]
                right_records = records[right_begin_index: right_begin_index + length]
                records[left_begin_index: right_begin_index + length] = self._merge(left_records,
                                                                                    right_records)

                left_begin_index = right_begin_index + length
                right_begin_index = left_begin_index + length

            if left_begin_index < n:
                left_records = records[left_begin_index: left_begin_index + length]
                right_records = records[right_begin_index: n]
                records[left_begin_index: n] = self._merge(left_records,
                                                           right_records)

            length *= 2

        return records

    def sort(self,
             records,
             extractor=None,
             is_order_natural=True):

        if not records:
            return records

        if not callable(extractor) and is_order_natural:
            self._record_extractor = lambda record: record
        elif not callable(extractor):
            self._record_extractor = lambda record: -record
        elif is_order_natural:
            self._record_extractor = lambda record: extractor(record)
        else:
            self._record_extractor = lambda record: -extractor(record)

        return self._sort(records)


def iterative_merge_sort(records,
                         extractor=None,
                         is_order_natural=True):

    merge_sorter = IterativeMergeSorter()

    return merge_sorter.sort(records,
                             extractor=extractor,
                             is_order_natural=is_order_natural)
