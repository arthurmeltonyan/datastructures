def bubble_sort(records,
                extractor=None,
                is_order_natural=True):

    if not records:
        return records

    if not callable(extractor) and is_order_natural:
        record_extractor = lambda record: record
    elif not callable(extractor):
        record_extractor = lambda record: -record
    elif is_order_natural:
        record_extractor = lambda record: extractor(record)
    else:
        record_extractor = lambda record: -extractor(record)

    n = len(records)
    for i in range(0, n):

        is_swapped = False
        for j in range(0, n - i - 1):
            if record_extractor(records[j]) > record_extractor(records[j + 1]):
                records[j], records[j + 1] = records[j + 1], records[j]
                is_swapped = True

        if not is_swapped:
            break

    return records
