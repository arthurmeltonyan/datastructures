class PowerSorter:

    def __init__(self):

        self._record_extractor = None

    def _merge(self,
               left_records,
               right_records):

        left_index = 0
        right_index = 0
        records = []

        while left_index < len(left_records) and right_index < len(right_records):

            if self._record_extractor(left_records[left_index]) < self._record_extractor(right_records[right_index]):
                record = left_records[left_index]
                left_index += 1
            else:
                record = right_records[right_index]
                right_index += 1

            records.append(record)

        records.extend(left_records[left_index:])
        records.extend(right_records[right_index:])

        return records

    def _detect_right_run(self,
                          records,
                          begin_index,
                          end_index):

        index = begin_index + 1
        while (index <= end_index and
               self._record_extractor(records[index - 1]) <= self._record_extractor(records[index])):
            index += 1

        return index - 1

    @staticmethod
    def _calculate_node_power(left_index,
                              left_run_left_index,
                              left_run_right_index,
                              right_run_left_index,
                              right_run_right_index,
                              right_index):

        n = right_index - left_index + 1

        left = left_run_left_index + right_run_left_index - 2 * left_index
        right = left_run_right_index + right_run_right_index - 2 * left_index

        left_value = (left << 30) // n
        right_value = (right << 30) // n

        return 32 - (left_value ^ right_value).bit_length()

    def _sort(self,
              records):

        n = len(records)
        run_left_index = 0
        run_right_index = self._detect_right_run(records,
                                                 run_left_index,
                                                 n - 1)

        triplet = (run_left_index, run_right_index, 0)
        triplets = [(0, 0, 0)] * (len(records).bit_length() + 1)
        top_index = 0

        triplets[top_index] = triplet
        run_left_index = run_right_index + 1

        while run_left_index < n:

            top_run_left_index, top_run_right_index, top_run_power = triplets[top_index]
            top_records = records[top_run_left_index: top_run_right_index + 1]

            run_right_index = self._detect_right_run(records,
                                                     run_left_index,
                                                     n - 1)
            power = self._calculate_node_power(0,
                                               top_run_left_index,
                                               top_run_right_index,
                                               run_left_index,
                                               run_right_index,
                                               n - 1)

            while top_index > 0 and top_run_power >= power:

                bottom_run_left_index, bottom_run_right_index, bottom_power = triplets[top_index - 1]
                bottom_records = records[bottom_run_left_index: bottom_run_right_index + 1]

                records[bottom_run_left_index: top_run_right_index + 1] = self._merge(top_records,
                                                                                      bottom_records)

                top_index -= 1
                triplet = (bottom_run_left_index, top_run_right_index, bottom_power)
                triplets[top_index] = triplet

                top_run_left_index, top_run_right_index, top_run_power = triplet
                top_records = records[top_run_left_index: top_run_right_index + 1]

            top_index += 1
            triplet = (run_left_index, run_right_index, power)
            triplets[top_index] = triplet

            run_left_index = run_right_index + 1

        top_run_left_index, top_run_right_index, top_run_power = triplets[top_index]
        top_records = records[top_run_left_index: top_run_right_index + 1]

        while top_index > 0:

            bottom_run_left_index, bottom_run_right_index, bottom_power = triplets[top_index - 1]
            bottom_records = records[bottom_run_left_index: bottom_run_right_index + 1]

            records[bottom_run_left_index: top_run_right_index + 1] = self._merge(top_records,
                                                                                  bottom_records)

            top_index -= 1
            triplet = (bottom_run_left_index, top_run_right_index, bottom_power)
            triplets[top_index] = triplet

            top_run_left_index, top_run_right_index, top_run_power = triplet
            top_records = records[top_run_left_index: top_run_right_index + 1]

        return records

    def sort(self,
             records,
             extractor=None,
             is_order_natural=True):

        if not records:
            return records

        if not callable(extractor) and is_order_natural:
            self._record_extractor = lambda record: record
        elif not callable(extractor):
            self._record_extractor = lambda record: -record
        elif is_order_natural:
            self._record_extractor = lambda record: extractor(record)
        else:
            self._record_extractor = lambda record: -extractor(record)

        return self._sort(records)


def power_sort(records,
               extractor=None,
               is_order_natural=True):

    power_sorter = PowerSorter()

    return power_sorter.sort(records,
                             extractor=extractor,
                             is_order_natural=is_order_natural)
