class RecursiveQuickSorter:

    def __init__(self):

        self._record_extractor = None

    def _pivot(self,
               records,
               initial_index,
               middle_index,
               terminal_index):

        initial_key = self._record_extractor(records[initial_index])
        middle_key = self._record_extractor(records[middle_index])
        terminal_key = self._record_extractor(records[terminal_index])

        if initial_key < middle_key:
            records[middle_index], records[initial_index] = records[initial_index], records[middle_index]
        if terminal_key < initial_key:
            records[initial_index], records[terminal_index] = records[terminal_index], records[initial_index]
        if initial_key < middle_key:
            records[middle_index], records[initial_index] = records[initial_index], records[middle_index]

        return initial_index

    def _partition(self,
                   records,
                   initial_index,
                   terminal_index,
                   pivot_index):

        pivot_key = self._record_extractor(records[pivot_index])
        records[pivot_index], records[initial_index] = records[initial_index], records[pivot_index]

        begin_index = initial_index + 1
        end_index = terminal_index
        did_indices_cross = False

        while not did_indices_cross:

            while begin_index <= terminal_index and pivot_key > self._record_extractor(records[begin_index]):
                begin_index += 1

            while end_index > initial_index and pivot_key < self._record_extractor(records[end_index]):
                end_index -= 1

            if begin_index <= end_index:
                records[begin_index], records[end_index] = records[end_index], records[begin_index]
                begin_index += 1
                end_index -= 1
            else:
                did_indices_cross = True

        records[end_index], records[initial_index] = records[initial_index], records[end_index]

        return end_index

    def _sort(self,
              records,
              initial_index,
              terminal_index):

        while terminal_index - initial_index > 1:

            pivot_index = self._pivot(records,
                                      initial_index,
                                      initial_index + (terminal_index - initial_index) // 2,
                                      terminal_index)
            partition_index = self._partition(records,
                                              initial_index,
                                              terminal_index,
                                              pivot_index)

            if partition_index - initial_index < terminal_index - partition_index:
                self._sort(records,
                           initial_index,
                           partition_index - 1)
                initial_index = partition_index + 1
            else:
                self._sort(records,
                           partition_index + 1,
                           terminal_index)
                terminal_index = partition_index - 1

        if terminal_index - initial_index == 1:

            initial_key = self._record_extractor(records[initial_index])
            terminal_key = self._record_extractor(records[terminal_index])

            if initial_key > terminal_key:
                records[initial_index], records[terminal_index] = records[terminal_index], records[initial_index]

    def sort(self,
             records,
             extractor=None,
             is_order_natural=True):

        if not records:
            return records

        if not callable(extractor) and is_order_natural:
            self._record_extractor = lambda record: record
        elif not callable(extractor):
            self._record_extractor = lambda record: -record
        elif is_order_natural:
            self._record_extractor = lambda record: extractor(record)
        else:
            self._record_extractor = lambda record: -extractor(record)

        self._sort(records,
                   0,
                   len(records) - 1)

        return records


def recursive_quick_sort(records,
                         extractor=None,
                         is_order_natural=True):

    quick_sorter = RecursiveQuickSorter()

    return quick_sorter.sort(records,
                             extractor=extractor,
                             is_order_natural=is_order_natural)


class IterativeQuickSorter:

    def __init__(self):

        self._record_extractor = None

    def _pivot(self,
               records,
               initial_index,
               middle_index,
               terminal_index):

        initial_key = self._record_extractor(records[initial_index])
        middle_key = self._record_extractor(records[middle_index])
        terminal_key = self._record_extractor(records[terminal_index])

        if initial_key < middle_key:
            records[middle_index], records[initial_index] = records[initial_index], records[middle_index]
        if terminal_key < initial_key:
            records[initial_index], records[terminal_index] = records[terminal_index], records[initial_index]
        if initial_key < middle_key:
            records[middle_index], records[initial_index] = records[initial_index], records[middle_index]

        return initial_index

    def _partition(self,
                   records,
                   initial_index,
                   terminal_index,
                   pivot_index):

        pivot_key = self._record_extractor(records[pivot_index])
        records[pivot_index], records[initial_index] = records[initial_index], records[pivot_index]

        begin_index = initial_index + 1
        end_index = terminal_index
        did_indices_cross = False

        while not did_indices_cross:

            while pivot_key > self._record_extractor(records[begin_index]) and begin_index <= terminal_index:
                begin_index += 1

            while pivot_key < self._record_extractor(records[end_index]) and end_index > initial_index:
                end_index -= 1

            if begin_index <= end_index:
                records[begin_index], records[end_index] = records[end_index], records[begin_index]
                begin_index += 1
                end_index -= 1
            else:
                did_indices_cross = True

        records[end_index], records[initial_index] = records[initial_index], records[end_index]

        return end_index

    def _sort(self,
              records):

        stack = [(0, len(records) - 1)]

        while stack:

            initial_index, terminal_index = stack.pop()

            if terminal_index - initial_index > 1:

                pivot_index = self._pivot(records,
                                          initial_index,
                                          initial_index + (terminal_index - initial_index) // 2,
                                          terminal_index)
                partition_index = self._partition(records,
                                                  initial_index,
                                                  terminal_index,
                                                  pivot_index)
                if partition_index - initial_index < terminal_index - partition_index:
                    stack.append((partition_index + 1, terminal_index))
                    stack.append((initial_index, partition_index - 1))
                else:
                    stack.append((initial_index, partition_index - 1))
                    stack.append((partition_index + 1, terminal_index))

            elif terminal_index - initial_index == 1:

                initial_key = self._record_extractor(records[initial_index])
                terminal_key = self._record_extractor(records[terminal_index])

                if initial_key > terminal_key:
                    records[initial_index], records[terminal_index] = records[terminal_index], records[initial_index]

    def sort(self,
             records,
             extractor=None,
             is_order_natural=True):

        if not records:
            return records

        if not callable(extractor) and is_order_natural:
            self._record_extractor = lambda record: record
        elif not callable(extractor):
            self._record_extractor = lambda record: -record
        elif is_order_natural:
            self._record_extractor = lambda record: extractor(record)
        else:
            self._record_extractor = lambda record: -extractor(record)

        self._sort(records)

        return records


def iterative_quick_sort(records,
                         extractor=None,
                         is_order_natural=True):

    quick_sorter = IterativeQuickSorter()

    return quick_sorter.sort(records,
                             extractor=extractor,
                             is_order_natural=is_order_natural)
