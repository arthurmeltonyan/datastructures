def insertion_sort(records,
                   extractor=None,
                   is_order_natural=True):

    if not records:
        return records

    if not callable(extractor) and is_order_natural:
        record_extractor = lambda record: record
    elif not callable(extractor):
        record_extractor = lambda record: -record
    elif is_order_natural:
        record_extractor = lambda record: extractor(record)
    else:
        record_extractor = lambda record: -extractor(record)

    n = len(records)
    for i in range(1, n):

        current_record = records[i]
        j = i - 1
        while j >= 0 and record_extractor(records[j]) > record_extractor(current_record):
            records[j + 1] = records[j]
            j -= 1
        records[j + 1] = current_record

    return records
