class RecursiveSwiftSorter:

    def __init__(self):

        self._record_extractor = None

    def _pivot(self,
               records,
               initial_index,
               middle_index,
               terminal_index):

        initial_key = self._record_extractor(records[initial_index])
        middle_key = self._record_extractor(records[middle_index])
        terminal_key = self._record_extractor(records[terminal_index])

        if initial_key < middle_key:
            records[middle_index], records[initial_index] = records[initial_index], records[middle_index]
        if terminal_key < initial_key:
            records[initial_index], records[terminal_index] = records[terminal_index], records[initial_index]
        if initial_key < middle_key:
            records[middle_index], records[initial_index] = records[initial_index], records[middle_index]

        return initial_index

    def _partition_left(self,
                        records,
                        initial_index,
                        terminal_index,
                        pivot_index):

        pivot_key = self._record_extractor(records[pivot_index])

        begin_index = initial_index
        end_index = terminal_index

        end_index -= 1
        while pivot_key < self._record_extractor(records[end_index]):
            end_index -= 1

        begin_index += 1
        while pivot_key >= self._record_extractor(records[begin_index]) and begin_index <= end_index:
            begin_index += 1

        while begin_index < end_index:

            records[begin_index], records[end_index] = records[end_index], records[begin_index]

            end_index -= 1
            while pivot_key < self._record_extractor(records[end_index]):
                end_index -= 1

            begin_index += 1
            while pivot_key >= self._record_extractor(records[begin_index]):
                begin_index += 1

        records[end_index], records[pivot_index] = records[pivot_index], records[end_index]

        return end_index

    def _partition_right(self,
                         records,
                         initial_index,
                         terminal_index,
                         pivot_index):

        pivot_key = self._record_extractor(records[pivot_index])

        begin_index = initial_index
        end_index = terminal_index

        begin_index += 1
        while pivot_key > self._record_extractor(records[begin_index]):
            begin_index += 1

        end_index -= 1
        while pivot_key <= self._record_extractor(records[end_index]) and begin_index <= end_index:
            end_index -= 1

        while begin_index < end_index:

            records[begin_index], records[end_index] = records[end_index], records[begin_index]

            begin_index += 1
            while pivot_key > self._record_extractor(records[begin_index]):
                begin_index += 1

            end_index -= 1
            while pivot_key <= self._record_extractor(records[end_index]):
                end_index -= 1

        records[begin_index - 1], records[pivot_index] = records[pivot_index], records[begin_index - 1]

        return begin_index - 1

    def _sort(self,
              records,
              initial_index,
              terminal_index,
              are_records_leftmost):

        while terminal_index - initial_index > 1:

            pivot_index = self._pivot(records,
                                      initial_index,
                                      initial_index + (terminal_index - initial_index) // 2,
                                      terminal_index)
            if are_records_leftmost:
                partition_index = self._partition_right(records,
                                                        initial_index,
                                                        terminal_index,
                                                        pivot_index)
                self._sort(records,
                           initial_index,
                           partition_index,
                           are_records_leftmost)
                initial_index = partition_index + 1
                are_records_leftmost = False
            elif records[initial_index - 1] == records[initial_index]:
                partition_index = self._partition_left(records,
                                                       initial_index,
                                                       terminal_index,
                                                       pivot_index)
                initial_index = partition_index + 1
            else:
                partition_index = self._partition_right(records,
                                                        initial_index,
                                                        terminal_index,
                                                        pivot_index)
                self._sort(records,
                           initial_index,
                           partition_index,
                           are_records_leftmost)
                initial_index = partition_index + 1
                are_records_leftmost = False

        if terminal_index - initial_index == 1:

            initial_key = self._record_extractor(records[initial_index])
            terminal_key = self._record_extractor(records[terminal_index])

            if initial_key > terminal_key:
                records[initial_index], records[terminal_index] = records[terminal_index], records[initial_index]

    def sort(self,
             records,
             extractor=None,
             is_order_natural=True):

        if not records:
            return records

        if not callable(extractor) and is_order_natural:
            self._record_extractor = lambda record: record
        elif not callable(extractor):
            self._record_extractor = lambda record: -record
        elif is_order_natural:
            self._record_extractor = lambda record: extractor(record)
        else:
            self._record_extractor = lambda record: -extractor(record)

        self._sort(records,
                   0,
                   len(records) - 1,
                   True)

        return records


def recursive_swift_sort(records,
                         extractor=None,
                         is_order_natural=True):

    swift_sorter = RecursiveSwiftSorter()

    return swift_sorter.sort(records,
                             extractor=extractor,
                             is_order_natural=is_order_natural)


class IterativeSwiftSorter:

    def __init__(self):

        self._record_extractor = None

    def _pivot(self,
               records,
               initial_index,
               middle_index,
               terminal_index):

        initial_key = self._record_extractor(records[initial_index])
        middle_key = self._record_extractor(records[middle_index])
        terminal_key = self._record_extractor(records[terminal_index])

        if initial_key < middle_key:
            records[middle_index], records[initial_index] = records[initial_index], records[middle_index]
        if terminal_key < initial_key:
            records[initial_index], records[terminal_index] = records[terminal_index], records[initial_index]
        if initial_key < middle_key:
            records[middle_index], records[initial_index] = records[initial_index], records[middle_index]

        return initial_index

    def _partition_left(self,
                        records,
                        initial_index,
                        terminal_index,
                        pivot_index):

        pivot_key = self._record_extractor(records[pivot_index])

        begin_index = initial_index
        end_index = terminal_index

        end_index -= 1
        while pivot_key < self._record_extractor(records[end_index]):
            end_index -= 1

        begin_index += 1
        while pivot_key >= self._record_extractor(records[begin_index]) and begin_index <= end_index:
            begin_index += 1

        while begin_index < end_index:

            records[begin_index], records[end_index] = records[end_index], records[begin_index]

            end_index -= 1
            while pivot_key < self._record_extractor(records[end_index]):
                end_index -= 1

            begin_index += 1
            while pivot_key >= self._record_extractor(records[begin_index]):
                begin_index += 1

        records[end_index], records[pivot_index] = records[pivot_index], records[end_index]

        return end_index

    def _partition_right(self,
                         records,
                         initial_index,
                         terminal_index,
                         pivot_index):

        pivot_key = self._record_extractor(records[pivot_index])

        begin_index = initial_index
        end_index = terminal_index

        begin_index += 1
        while pivot_key > self._record_extractor(records[begin_index]):
            begin_index += 1

        end_index -= 1
        while pivot_key <= self._record_extractor(records[end_index]) and begin_index <= end_index:
            end_index -= 1

        while begin_index < end_index:

            records[begin_index], records[end_index] = records[end_index], records[begin_index]

            begin_index += 1
            while pivot_key > self._record_extractor(records[begin_index]):
                begin_index += 1

            end_index -= 1
            while pivot_key <= self._record_extractor(records[end_index]):
                end_index -= 1

        records[begin_index - 1], records[pivot_index] = records[pivot_index], records[begin_index - 1]

        return begin_index - 1

    def _sort(self,
              records):

        stack = [(0, len(records) - 1, True)]

        while stack:

            initial_index, terminal_index, are_records_leftmost = stack.pop()

            if terminal_index - initial_index > 1:

                pivot_index = self._pivot(records,
                                          initial_index,
                                          initial_index + (terminal_index - initial_index) // 2,
                                          terminal_index)
                if are_records_leftmost:
                    partition_index = self._partition_right(records,
                                                            initial_index,
                                                            terminal_index,
                                                            pivot_index)
                    stack.append((initial_index, partition_index - 1, are_records_leftmost))
                    stack.append((partition_index + 1, terminal_index, False))
                elif records[initial_index - 1] == records[initial_index]:
                    partition_index = self._partition_left(records,
                                                           initial_index,
                                                           terminal_index,
                                                           pivot_index)
                    stack.append((partition_index + 1, terminal_index, are_records_leftmost))
                else:
                    partition_index = self._partition_right(records,
                                                            initial_index,
                                                            terminal_index,
                                                            pivot_index)
                    stack.append((initial_index, partition_index - 1, are_records_leftmost))
                    stack.append((partition_index + 1, terminal_index, False))

            elif terminal_index - initial_index == 1:

                initial_key = self._record_extractor(records[initial_index])
                terminal_key = self._record_extractor(records[terminal_index])

                if initial_key > terminal_key:
                    records[initial_index], records[terminal_index] = records[terminal_index], records[initial_index]

    def sort(self,
             records,
             extractor=None,
             is_order_natural=True):

        if not records:
            return records

        if not callable(extractor) and is_order_natural:
            self._record_extractor = lambda record: record
        elif not callable(extractor):
            self._record_extractor = lambda record: -record
        elif is_order_natural:
            self._record_extractor = lambda record: extractor(record)
        else:
            self._record_extractor = lambda record: -extractor(record)

        self._sort(records)

        return records


def iterative_swift_sort(records,
                         extractor=None,
                         is_order_natural=True):

    swift_sorter = IterativeSwiftSorter()

    return swift_sorter.sort(records,
                             extractor=extractor,
                             is_order_natural=is_order_natural)
