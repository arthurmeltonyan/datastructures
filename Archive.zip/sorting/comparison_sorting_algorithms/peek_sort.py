class PeekSorter:

    def __init__(self):

        self._record_extractor = None

    def _merge(self,
               left_records,
               right_records):

        left_index = 0
        right_index = 0
        records = []

        while left_index < len(left_records) and right_index < len(right_records):

            if self._record_extractor(left_records[left_index]) < self._record_extractor(right_records[right_index]):
                record = left_records[left_index]
                left_index += 1
            else:
                record = right_records[right_index]
                right_index += 1

            records.append(record)

        records.extend(left_records[left_index:])
        records.extend(right_records[right_index:])

        return records

    def _detect_left_run(self,
                         records,
                         begin_index,
                         end_index):

        index = begin_index - 1
        while (index >= end_index and
               self._record_extractor(records[index]) <= self._record_extractor(records[index + 1])):
            index -= 1

        return index + 1

    def _detect_right_run(self,
                          records,
                          begin_index,
                          end_index):

        index = begin_index + 1
        while (index <= end_index
               and self._record_extractor(records[index - 1]) <= self._record_extractor(records[index])):
            index += 1

        return index - 1

    def _sort(self,
              records,
              left_index,
              left_run_right_index,
              right_run_left_index,
              right_index):

        if right_index == left_run_right_index or left_index == right_run_left_index:
            return records[left_index: right_index + 1]

        midpoint = left_index + (right_index - left_index) // 2

        if midpoint <= left_run_right_index:
            left_records = records[left_index: left_run_right_index + 1]
            right_records = self._sort(records,
                                       left_run_right_index + 1,
                                       left_run_right_index + 1,
                                       right_run_left_index,
                                       right_index)
        elif midpoint >= right_run_left_index:
            left_records = self._sort(records,
                                      left_index,
                                      left_run_right_index,
                                      right_run_left_index - 1,
                                      right_run_left_index - 1)
            right_records = records[right_run_left_index: right_index + 1]
        else:
            left_run_left_index = self._detect_left_run(records,
                                                        midpoint,
                                                        left_index)
            right_run_right_index = self._detect_right_run(records,
                                                           midpoint,
                                                           right_index)

            if left_run_left_index == left_index and right_run_right_index == right_index:
                return records[left_index: right_index + 1]
            elif midpoint - left_run_left_index < right_run_right_index - midpoint:
                left_records = self._sort(records,
                                          left_index,
                                          left_run_right_index,
                                          left_run_left_index - 1,
                                          left_run_left_index - 1)
                right_records = self._sort(records,
                                           left_run_left_index,
                                           right_run_right_index,
                                           right_run_left_index,
                                           right_index)
            else:
                left_records = self._sort(records,
                                          left_index,
                                          left_run_right_index,
                                          left_run_left_index,
                                          right_run_right_index)
                right_records = self._sort(records,
                                           right_run_right_index + 1,
                                           right_run_right_index + 1,
                                           right_run_left_index,
                                           right_index)

        return self._merge(left_records,
                           right_records)

    def sort(self,
             records,
             extractor=None,
             is_order_natural=True):

        if not records:
            return records

        if not callable(extractor) and is_order_natural:
            self._record_extractor = lambda record: record
        elif not callable(extractor):
            self._record_extractor = lambda record: -record
        elif is_order_natural:
            self._record_extractor = lambda record: extractor(record)
        else:
            self._record_extractor = lambda record: -extractor(record)

        return self._sort(records,
                          0,
                          0,
                          len(records) - 1,
                          len(records) - 1)


def peek_sort(records,
              extractor=None,
              is_order_natural=True):

    peek_sorter = PeekSorter()

    return peek_sorter.sort(records,
                            extractor=extractor,
                            is_order_natural=is_order_natural)
