import pytest
import random

import selection_sort
import bubble_sort
import insertion_sort
import quick_sort
import swift_sort
import merge_sort
import peek_sort
import power_sort


@pytest.fixture
def few_unsorted_records():

    return [random.randint(-1000, 1000)
            for _ in range(1000)]


@pytest.fixture
def few_naturally_sorted_records(few_unsorted_records):

    return sorted(few_unsorted_records,
                  reverse=False)


@pytest.fixture
def few_reversely_sorted_records(few_naturally_sorted_records):

    return few_naturally_sorted_records[::-1]


class TestSelectionSort:

    @staticmethod
    def test_natural(few_unsorted_records,
                     few_naturally_sorted_records):

        sorted_records = selection_sort.selection_sort(few_unsorted_records,
                                                       is_order_natural=True)
        assert sorted_records == few_naturally_sorted_records

    @staticmethod
    def test_reverse(few_unsorted_records,
                     few_reversely_sorted_records):

        sorted_records = selection_sort.selection_sort(few_unsorted_records,
                                                       is_order_natural=False)
        assert sorted_records == few_reversely_sorted_records


class TestBubbleSort:

    @staticmethod
    def test_natural(few_unsorted_records,
                     few_naturally_sorted_records):

        sorted_records = bubble_sort.bubble_sort(few_unsorted_records,
                                                 is_order_natural=True)
        assert sorted_records == few_naturally_sorted_records

    @staticmethod
    def test_reverse(few_unsorted_records,
                     few_reversely_sorted_records):

        sorted_records = bubble_sort.bubble_sort(few_unsorted_records,
                                                 is_order_natural=False)
        assert sorted_records == few_reversely_sorted_records


class TestInsertionSort:

    @staticmethod
    def test_natural(few_unsorted_records,
                     few_naturally_sorted_records):

        sorted_records = insertion_sort.insertion_sort(few_unsorted_records,
                                                       is_order_natural=True)
        assert sorted_records == few_naturally_sorted_records

    @staticmethod
    def test_reverse(few_unsorted_records,
                     few_reversely_sorted_records):

        sorted_records = insertion_sort.insertion_sort(few_unsorted_records,
                                                       is_order_natural=False)
        assert sorted_records == few_reversely_sorted_records


@pytest.fixture
def many_unsorted_records():

    return [random.randint(-1000000, 1000000)
            for _ in range(1000000)]


@pytest.fixture
def many_naturally_sorted_records(many_unsorted_records):

    return sorted(many_unsorted_records,
                  reverse=False)


@pytest.fixture
def many_reversely_sorted_records(many_naturally_sorted_records):

    return many_naturally_sorted_records[::-1]


class TestRecursiveQuickSort:

    @staticmethod
    def test_natural(many_unsorted_records,
                     many_naturally_sorted_records):

        sorted_records = quick_sort.recursive_quick_sort(many_unsorted_records,
                                                         is_order_natural=True)
        assert sorted_records == many_naturally_sorted_records

    @staticmethod
    def test_reverse(many_unsorted_records,
                     many_reversely_sorted_records):

        sorted_records = quick_sort.recursive_quick_sort(many_unsorted_records,
                                                         is_order_natural=False)
        assert sorted_records == many_reversely_sorted_records


class TestIterativeQuickSort:

    @staticmethod
    def test_natural(many_unsorted_records,
                     many_naturally_sorted_records):

        sorted_records = quick_sort.iterative_quick_sort(many_unsorted_records,
                                                         is_order_natural=True)
        assert sorted_records == many_naturally_sorted_records

    @staticmethod
    def test_reverse(many_unsorted_records,
                     many_reversely_sorted_records):

        sorted_records = quick_sort.iterative_quick_sort(many_unsorted_records,
                                                         is_order_natural=False)
        assert sorted_records == many_reversely_sorted_records


class TestRecursiveSwiftSort:

    @staticmethod
    def test_natural(many_unsorted_records,
                     many_naturally_sorted_records):

        sorted_records = swift_sort.recursive_swift_sort(many_unsorted_records,
                                                         is_order_natural=True)
        assert sorted_records == many_naturally_sorted_records

    @staticmethod
    def test_reverse(many_unsorted_records,
                     many_reversely_sorted_records):

        sorted_records = swift_sort.recursive_swift_sort(many_unsorted_records,
                                                         is_order_natural=False)
        assert sorted_records == many_reversely_sorted_records


class TestIterativeSwiftSort:

    @staticmethod
    def test_natural(many_unsorted_records,
                     many_naturally_sorted_records):

        sorted_records = swift_sort.iterative_swift_sort(many_unsorted_records,
                                                         is_order_natural=True)
        assert sorted_records == many_naturally_sorted_records

    @staticmethod
    def test_reverse(many_unsorted_records,
                     many_reversely_sorted_records):

        sorted_records = swift_sort.iterative_swift_sort(many_unsorted_records,
                                                         is_order_natural=False)
        assert sorted_records == many_reversely_sorted_records


class TestRecursiveMergeSort:

    @staticmethod
    def test_natural(many_unsorted_records,
                     many_naturally_sorted_records):

        sorted_records = merge_sort.recursive_merge_sort(many_unsorted_records,
                                                         is_order_natural=True)
        assert sorted_records == many_naturally_sorted_records

    @staticmethod
    def test_reverse(many_unsorted_records,
                     many_reversely_sorted_records):

        sorted_records = merge_sort.recursive_merge_sort(many_unsorted_records,
                                                         is_order_natural=False)
        assert sorted_records == many_reversely_sorted_records


class TestIterativeMergeSort:

    @staticmethod
    def test_natural(many_unsorted_records,
                     many_naturally_sorted_records):

        sorted_records = merge_sort.iterative_merge_sort(many_unsorted_records,
                                                         is_order_natural=True)
        assert sorted_records == many_naturally_sorted_records

    @staticmethod
    def test_reverse(many_unsorted_records,
                     many_reversely_sorted_records):

        sorted_records = merge_sort.iterative_merge_sort(many_unsorted_records,
                                                         is_order_natural=False)
        assert sorted_records == many_reversely_sorted_records


class TestPeekSort:

    @staticmethod
    def test_natural(many_unsorted_records,
                     many_naturally_sorted_records):

        sorted_records = peek_sort.peek_sort(many_unsorted_records,
                                             is_order_natural=True)
        assert sorted_records == many_naturally_sorted_records

    @staticmethod
    def test_reverse(many_unsorted_records,
                     many_reversely_sorted_records):

        sorted_records = peek_sort.peek_sort(many_unsorted_records,
                                             is_order_natural=False)
        assert sorted_records == many_reversely_sorted_records


class TestPowerSort:

    @staticmethod
    def test_natural(many_unsorted_records,
                     many_naturally_sorted_records):

        sorted_records = power_sort.power_sort(many_unsorted_records,
                                               is_order_natural=True)
        assert sorted_records == many_naturally_sorted_records

    @staticmethod
    def test_reverse(many_unsorted_records,
                     many_reversely_sorted_records):

        sorted_records = power_sort.power_sort(many_unsorted_records,
                                               is_order_natural=False)
        assert sorted_records == many_reversely_sorted_records
