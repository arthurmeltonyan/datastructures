def selection_sort(records,
                   extractor=None,
                   is_order_natural=True):

    if not records:
        return records

    if not callable(extractor) and is_order_natural:
        record_extractor = lambda record: record
    elif not callable(extractor):
        record_extractor = lambda record: -record
    elif is_order_natural:
        record_extractor = lambda record: extractor(record)
    else:
        record_extractor = lambda record: -extractor(record)

    n = len(records)
    for i in range(0, n):

        target_index = i
        for j in range(i + 1, n):
            if record_extractor(records[j]) < record_extractor(records[target_index]):
                target_index = j
            elif record_extractor(records[j]) == record_extractor(records[target_index]) and j < target_index:
                target_index = j

        if target_index != i:
            target_value = records[target_index]
            for j in reversed(range(i + 1, target_index + 1)):
                records[j] = records[j - 1]
            records[i] = target_value

    return records
