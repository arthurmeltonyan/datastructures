class RecursiveMSDRadixQuickerSorter:

    def __init__(self):

        self._record_extractor = None
        self._character_code_extractor = None
        self._minimum_character_code = None
        self._maximum_character_code = None

    def _natural_code_extractor(self,
                                record,
                                character_index):

        raw_string = self._record_extractor(record)

        if character_index < len(raw_string):
            return ord(raw_string[character_index]) - self._minimum_character_code
        else:
            return -float('inf')

    def _reverse_code_extractor(self,
                                record,
                                character_index):

        raw_string = self._record_extractor(record)

        if character_index < len(raw_string):
            return self._maximum_character_code - ord(raw_string[character_index])
        else:
            return float('inf')

    def _place_non_empty_first(self,
                               records,
                               character_index,
                               initial_index,
                               middle_index,
                               terminal_index):

        initial_key = self._character_code_extractor(records[initial_index], character_index)
        if initial_key == float('inf') or initial_key == -float('inf'):
            return

        middle_key = self._character_code_extractor(records[middle_index], character_index)
        if middle_key == float('inf') or middle_key == -float('inf'):
            records[initial_index], records[middle_index] = records[middle_index], records[initial_index]
            return

        terminal_key = self._character_code_extractor(records[terminal_index], character_index)
        if terminal_key == float('inf') or terminal_key == -float('inf'):
            records[initial_index], records[terminal_index] = records[terminal_index], records[initial_index]
            return

    def _partition(self,
                   records,
                   character_index,
                   initial_index,
                   terminal_index):

        pivot_index = initial_index
        pivot_key = self._character_code_extractor(records[pivot_index], character_index)

        begin_index = initial_index
        end_index = terminal_index

        left_index = initial_index - 1
        right_index = terminal_index + 1

        while begin_index <= end_index:

            while self._character_code_extractor(records[begin_index], character_index) < pivot_key:
                begin_index += 1

            while self._character_code_extractor(records[end_index], character_index) > pivot_key:
                end_index -= 1

            if begin_index < end_index:

                begin_key = self._character_code_extractor(records[begin_index], character_index)
                end_key = self._character_code_extractor(records[end_index], character_index)

                if pivot_key != begin_key and pivot_key != end_key:
                    records[begin_index], records[end_index] = records[end_index], records[begin_index]
                elif pivot_key != begin_key:
                    records[begin_index], records[end_index] = records[end_index], records[begin_index]
                    left_index += 1
                    records[left_index], records[begin_index] = records[begin_index], records[left_index]
                elif pivot_key != end_key:
                    records[begin_index], records[end_index] = records[end_index], records[begin_index]
                    right_index -= 1
                    records[right_index], records[end_index] = records[end_index], records[right_index]
                else:
                    left_index += 1
                    records[left_index], records[begin_index] = records[begin_index], records[left_index]
                    right_index -= 1
                    records[right_index], records[end_index] = records[end_index], records[right_index]

                begin_index += 1
                end_index -= 1

            elif begin_index == end_index:

                begin_index += 1
                end_index -= 1

        for k in range(initial_index, left_index + 1, 1):
            records[k], records[end_index] = records[end_index], records[k]
            end_index -= 1

        for k in range(terminal_index, right_index - 1, -1):
            records[k], records[begin_index] = records[begin_index], records[k]
            begin_index += 1

        return (end_index,
                begin_index)

    def _sort(self,
              records,
              character_index,
              initial_index,
              terminal_index):

        is_pivot_key_non_empty = True

        while terminal_index - initial_index > 1 and is_pivot_key_non_empty:

            self._place_non_empty_first(records,
                                        character_index,
                                        initial_index,
                                        initial_index + (terminal_index - initial_index) // 2,
                                        terminal_index)
            pivot_index = initial_index
            pivot_key = self._character_code_extractor(records[pivot_index], character_index)
            is_current_pivot_key_non_empty = pivot_key != float('inf') and pivot_key != -float('inf')

            left_partition_index, right_partition_index = self._partition(records,
                                                                          character_index,
                                                                          initial_index,
                                                                          terminal_index)
            left_length = left_partition_index - initial_index + 1
            middle_length = (right_partition_index - 1) - (left_partition_index + 1) + 1
            right_length = terminal_index - right_partition_index + 1

            if middle_length < left_length and right_length < left_length:
                if not is_current_pivot_key_non_empty:
                    self._sort(records,
                               character_index,
                               right_partition_index,
                               terminal_index)
                elif right_length < middle_length:
                    self._sort(records,
                               character_index,
                               right_partition_index,
                               terminal_index)
                    self._sort(records,
                               character_index + 1,
                               left_partition_index + 1,
                               right_partition_index - 1)
                else:
                    self._sort(records,
                               character_index + 1,
                               left_partition_index + 1,
                               right_partition_index - 1)
                    self._sort(records,
                               character_index,
                               right_partition_index,
                               terminal_index)
                terminal_index = left_partition_index
            elif middle_length < right_length and left_length < right_length:
                if not is_current_pivot_key_non_empty:
                    self._sort(records,
                               character_index,
                               initial_index,
                               left_partition_index)
                elif left_length < middle_length:
                    self._sort(records,
                               character_index,
                               initial_index,
                               left_partition_index)
                    self._sort(records,
                               character_index + 1,
                               left_partition_index + 1,
                               right_partition_index - 1)
                else:
                    self._sort(records,
                               character_index + 1,
                               left_partition_index + 1,
                               right_partition_index - 1)
                    self._sort(records,
                               character_index,
                               initial_index,
                               left_partition_index)
                initial_index = right_partition_index
            else:
                if left_length < right_length:
                    self._sort(records,
                               character_index,
                               initial_index,
                               left_partition_index)
                    self._sort(records,
                               character_index,
                               right_partition_index,
                               terminal_index)
                else:
                    self._sort(records,
                               character_index,
                               right_partition_index,
                               terminal_index)
                    self._sort(records,
                               character_index,
                               initial_index,
                               left_partition_index)
                character_index += 1
                initial_index = left_partition_index + 1
                terminal_index = right_partition_index - 1
                is_pivot_key_non_empty = is_current_pivot_key_non_empty

        if terminal_index - initial_index == 1:

            initial_key = self._character_code_extractor(records[initial_index], character_index)
            terminal_key = self._character_code_extractor(records[terminal_index], character_index)
            is_initial_character_non_empty = initial_key != float('inf') and initial_key != -float('inf')
            is_terminal_character_non_empty = terminal_key != float('inf') and terminal_key != -float('inf')

            while (initial_key == terminal_key and
                   (is_initial_character_non_empty or is_terminal_character_non_empty)):

                character_index += 1

                initial_key = self._character_code_extractor(records[initial_index], character_index)
                terminal_key = self._character_code_extractor(records[terminal_index], character_index)
                is_initial_character_non_empty = initial_key != float('inf') and initial_key != -float('inf')
                is_terminal_character_non_empty = terminal_key != float('inf') and terminal_key != -float('inf')

            if initial_key > terminal_key:
                records[initial_index], records[terminal_index] = records[terminal_index], records[initial_index]

    def sort(self,
             records,
             extractor=None,
             is_order_natural=True):

        if not records:
            return records

        if not callable(extractor):
            self._record_extractor = lambda value: value
        else:
            self._record_extractor = extractor

        self._minimum_character_code = min(ord(character)
                                           for record in records
                                           for character in self._record_extractor(record))
        self._maximum_character_code = max(ord(character)
                                           for record in records
                                           for character in self._record_extractor(record))

        if is_order_natural:
            self._character_code_extractor = self._natural_code_extractor
        else:
            self._character_code_extractor = self._reverse_code_extractor

        self._sort(records,
                   0,
                   0,
                   len(records) - 1)

        self._record_extractor = None
        self._character_code_extractor = None
        self._minimum_character_code = None
        self._maximum_character_code = None

        return records


def recursive_msd_radix_quicker_sort(records,
                                     extractor=None,
                                     is_order_natural=True):

    quick_sorter = RecursiveMSDRadixQuickerSorter()

    return quick_sorter.sort(records,
                             extractor=extractor,
                             is_order_natural=is_order_natural)


class IterativeMSDRadixQuickerSorter:

    def __init__(self):

        self._record_extractor = None
        self._character_code_extractor = None
        self._minimum_character_code = None
        self._maximum_character_code = None

    def _natural_code_extractor(self,
                                record,
                                character_index):

        raw_string = self._record_extractor(record)

        if character_index < len(raw_string):
            return 1 + ord(raw_string[character_index]) - self._minimum_character_code
        else:
            return -float('inf')

    def _reverse_code_extractor(self,
                                record,
                                character_index):

        raw_string = self._record_extractor(record)

        if character_index < len(raw_string):
            return self._maximum_character_code - ord(raw_string[character_index])
        else:
            return float('inf')

    def _place_non_empty_first(self,
                               records,
                               character_index,
                               initial_index,
                               middle_index,
                               terminal_index):

        initial_key = self._character_code_extractor(records[initial_index], character_index)
        if initial_key == float('inf') or initial_key == -float('inf'):
            return

        middle_key = self._character_code_extractor(records[middle_index], character_index)
        if middle_key == float('inf') or middle_key == -float('inf'):
            records[initial_index], records[middle_index] = records[middle_index], records[initial_index]
            return

        terminal_key = self._character_code_extractor(records[terminal_index], character_index)
        if terminal_key == float('inf') or terminal_key == -float('inf'):
            records[initial_index], records[terminal_index] = records[terminal_index], records[initial_index]
            return

    def _partition(self,
                   records,
                   character_index,
                   initial_index,
                   terminal_index):

        pivot_index = initial_index
        pivot_key = self._character_code_extractor(records[pivot_index], character_index)

        begin_index = initial_index
        end_index = terminal_index

        left_index = initial_index - 1
        right_index = terminal_index + 1

        while begin_index <= end_index:

            while self._character_code_extractor(records[begin_index], character_index) < pivot_key:
                begin_index += 1

            while self._character_code_extractor(records[end_index], character_index) > pivot_key:
                end_index -= 1

            if begin_index < end_index:

                if (pivot_key != self._character_code_extractor(records[begin_index], character_index)
                        and pivot_key != self._character_code_extractor(records[end_index], character_index)):
                    records[begin_index], records[end_index] = records[end_index], records[begin_index]
                elif pivot_key != self._character_code_extractor(records[begin_index], character_index):
                    records[begin_index], records[end_index] = records[end_index], records[begin_index]
                    left_index += 1
                    records[left_index], records[begin_index] = records[begin_index], records[left_index]
                elif pivot_key != self._character_code_extractor(records[end_index], character_index):
                    records[begin_index], records[end_index] = records[end_index], records[begin_index]
                    right_index -= 1
                    records[right_index], records[end_index] = records[end_index], records[right_index]
                else:
                    left_index += 1
                    records[left_index], records[begin_index] = records[begin_index], records[left_index]
                    right_index -= 1
                    records[right_index], records[end_index] = records[end_index], records[right_index]

                begin_index += 1
                end_index -= 1

            elif begin_index == end_index:

                begin_index += 1
                end_index -= 1

        for k in range(initial_index, left_index + 1, 1):
            records[k], records[end_index] = records[end_index], records[k]
            end_index -= 1

        for k in range(terminal_index, right_index - 1, -1):
            records[k], records[begin_index] = records[begin_index], records[k]
            begin_index += 1

        return (end_index,
                begin_index)

    def _sort(self,
              records):

        stack = [(0, 0, len(records) - 1, True)]

        while stack:

            initial_index, terminal_index, character_index, is_pivot_key_non_empty = stack.pop()

            if terminal_index - initial_index > 1 and is_pivot_key_non_empty:

                self._place_non_empty_first(records,
                                            character_index,
                                            initial_index,
                                            initial_index + (terminal_index - initial_index) // 2,
                                            terminal_index)
                pivot_index = initial_index
                pivot_key = self._character_code_extractor(records[pivot_index], character_index)
                is_current_pivot_key_non_empty = pivot_key != float('inf') and pivot_key != -float('inf')

                left_partition_index, right_partition_index = self._partition(records,
                                                                              character_index,
                                                                              initial_index,
                                                                              terminal_index)
                left_length = left_partition_index - initial_index + 1
                middle_length = (right_partition_index - 1) - (left_partition_index + 1) + 1
                right_length = terminal_index - right_partition_index + 1

                if left_length > middle_length and left_length > right_length:
                    if not is_current_pivot_key_non_empty:
                        stack.append((character_index, right_partition_index, terminal_index))
                        stack.append((character_index, initial_index, left_partition_index))
                    if middle_length > right_length:
                        stack.append((character_index, right_partition_index, terminal_index))
                        stack.append((character_index + 1, left_partition_index + 1, right_partition_index - 1))
                        stack.append((character_index, initial_index, left_partition_index))
                    else:
                        stack.append((character_index, right_partition_index, terminal_index))
                        stack.append((character_index, initial_index, left_partition_index))

                    stack.append((character_index, right_partition_index, terminal_index))
                    stack.append((character_index, initial_index, left_partition_index))
                elif right_length > max(middle_length, left_length):
                    if is_current_pivot_key_non_empty:
                        stack.append((character_index + 1, left_partition_index + 1, right_partition_index - 1))
                    stack.append((character_index, initial_index, left_partition_index))
                    stack.append((character_index, right_partition_index, terminal_index))
                else:
                    stack.append((character_index, initial_index, left_partition_index))
                    stack.append((character_index, right_partition_index, terminal_index))
                    if is_current_pivot_key_non_empty:
                        stack.append((character_index + 1, left_partition_index + 1, right_partition_index - 1))

            elif terminal_index - initial_index == 1:

                initial_key = self._character_code_extractor(records[initial_index], character_index)
                terminal_key = self._character_code_extractor(records[terminal_index], character_index)
                is_initial_character_non_empty = initial_key != float('inf') and initial_key != -float('inf')
                is_terminal_character_non_empty = terminal_key != float('inf') and terminal_key != -float('inf')

                while (initial_key == terminal_key and
                       (is_initial_character_non_empty or is_terminal_character_non_empty)):

                    character_index += 1

                    initial_key = self._character_code_extractor(records[initial_index], character_index)
                    terminal_key = self._character_code_extractor(records[terminal_index], character_index)
                    is_initial_character_non_empty = initial_key != float('inf') and initial_key != -float('inf')
                    is_terminal_character_non_empty = terminal_key != float('inf') and terminal_key != -float('inf')

                if initial_key > terminal_key:
                    records[initial_index], records[terminal_index] = records[terminal_index], records[initial_index]

    def sort(self,
             records,
             extractor=None,
             is_order_natural=True):

        if not records:
            return records

        if not callable(extractor):
            self._record_extractor = lambda value: value
        else:
            self._record_extractor = extractor

        self._minimum_character_code = min(ord(character)
                                           for record in records
                                           for character in self._record_extractor(record))
        self._maximum_character_code = max(ord(character)
                                           for record in records
                                           for character in self._record_extractor(record))

        if is_order_natural:
            self._character_code_extractor = self._natural_code_extractor
        else:
            self._character_code_extractor = self._reverse_code_extractor

        self._sort(records)

        self._record_extractor = None
        self._character_code_extractor = None
        self._minimum_character_code = None
        self._maximum_character_code = None

        return records


def iterative_msd_radix_quicker_sort(records,
                                     extractor=None,
                                     is_order_natural=True):

    quick_sorter = IterativeMSDRadixQuickerSorter()

    return quick_sorter.sort(records,
                             extractor=extractor,
                             is_order_natural=is_order_natural)
