import pytest
import random
import string

import radix_sort
import radix_quicker_sort


@pytest.fixture
def unsorted_alphabetical_records():

    characters = string.ascii_letters + string.digits

    return [''.join(random.choices(characters,
                                   k=random.randint(5, 15)))
            for _ in range(1000000)]


@pytest.fixture
def naturally_sorted_alphabetical_records(unsorted_alphabetical_records):

    return sorted(unsorted_alphabetical_records,
                  reverse=False)


@pytest.fixture
def reversely_sorted_alphabetical_records(naturally_sorted_alphabetical_records):

    return naturally_sorted_alphabetical_records[::-1]


class TestAlphabeticalLSDRadixSort:

    @staticmethod
    def test_natural(unsorted_alphabetical_records,
                     naturally_sorted_alphabetical_records):

        sorted_records = radix_sort.alphabetical_lsd_radix_sort(unsorted_alphabetical_records,
                                                                is_order_natural=True)
        assert sorted_records == naturally_sorted_alphabetical_records

    @staticmethod
    def test_reverse(unsorted_alphabetical_records,
                     reversely_sorted_alphabetical_records):

        sorted_records = radix_sort.alphabetical_lsd_radix_sort(unsorted_alphabetical_records,
                                                                is_order_natural=False)
        assert sorted_records == reversely_sorted_alphabetical_records


class TestRecursiveAlphabeticalMSDRadixSort:

    @staticmethod
    def test_natural(unsorted_alphabetical_records,
                     naturally_sorted_alphabetical_records):

        sorted_records = radix_sort.recursive_alphabetical_msd_radix_sort(unsorted_alphabetical_records,
                                                                          is_order_natural=True)
        assert sorted_records == naturally_sorted_alphabetical_records

    @staticmethod
    def test_reverse(unsorted_alphabetical_records,
                     reversely_sorted_alphabetical_records):

        sorted_records = radix_sort.recursive_alphabetical_msd_radix_sort(unsorted_alphabetical_records,
                                                                          is_order_natural=False)
        assert sorted_records == reversely_sorted_alphabetical_records


class TestIterativeAlphabeticalMSDRadixSort:

    @staticmethod
    def test_natural(unsorted_alphabetical_records,
                     naturally_sorted_alphabetical_records):

        sorted_records = radix_sort.iterative_alphabetical_msd_radix_sort(unsorted_alphabetical_records,
                                                                          is_order_natural=True)
        assert sorted_records == naturally_sorted_alphabetical_records

    @staticmethod
    def test_reverse(unsorted_alphabetical_records,
                     reversely_sorted_alphabetical_records):

        sorted_records = radix_sort.iterative_alphabetical_msd_radix_sort(unsorted_alphabetical_records,
                                                                          is_order_natural=False)
        assert sorted_records == reversely_sorted_alphabetical_records


class TestRecursiveMSDRadixQuickerSort:

    @staticmethod
    def test_natural(unsorted_alphabetical_records,
                     naturally_sorted_alphabetical_records):

        sorted_records = radix_quicker_sort.recursive_msd_radix_quicker_sort(unsorted_alphabetical_records,
                                                                             is_order_natural=True)
        assert sorted_records == naturally_sorted_alphabetical_records

    @staticmethod
    def test_reverse(unsorted_alphabetical_records,
                     reversely_sorted_alphabetical_records):

        sorted_records = radix_quicker_sort.recursive_msd_radix_quicker_sort(unsorted_alphabetical_records,
                                                                             is_order_natural=False)
        assert sorted_records == reversely_sorted_alphabetical_records
