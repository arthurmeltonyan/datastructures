class AlphabeticalLSDRadixSorter:

    def __init__(self):

        self._record_extractor = None
        self._character_code_extractor = None
        self._minimum_character_code = None
        self._maximum_character_code = None

    def _natural_code_extractor(self,
                                record,
                                index):

        raw_string = self._record_extractor(record)

        if index < len(raw_string):
            return 1 + ord(raw_string[index]) - self._minimum_character_code
        else:
            return 0

    def _reverse_code_extractor(self,
                                record,
                                index):

        raw_string = self._record_extractor(record)

        if index < len(raw_string):
            return self._maximum_character_code - ord(raw_string[index])
        else:
            return self._maximum_character_code - self._minimum_character_code + 1

    def _counting_sort(self,
                       records,
                       initial_index,
                       terminal_index,
                       character_index):

        if initial_index >= terminal_index:
            return records

        range_size = (self._maximum_character_code - self._minimum_character_code + 2)

        number_to_count = [0] * range_size
        for record in records[initial_index: terminal_index + 1]:
            number = self._character_code_extractor(record, character_index)
            number_to_count[number] += 1

        for number in range(1, range_size):
            number_to_count[number] += number_to_count[number - 1]

        sorted_records = [None] * (terminal_index - initial_index + 1)
        for record in reversed(records[initial_index: terminal_index + 1]):
            number = self._character_code_extractor(record, character_index)
            number_to_count[number] -= 1
            sorted_index = number_to_count[number]
            sorted_records[sorted_index] = record

        records[initial_index: terminal_index + 1] = sorted_records

        return records

    def _radix_sort(self,
                    records):

        maximum_length = max(len(self._record_extractor(record))
                             for record in records)

        if maximum_length == 0:
            return records

        for character_index in reversed(range(0, maximum_length)):
            records = self._counting_sort(records,
                                          0,
                                          len(records) - 1,
                                          character_index)

        return records

    def sort(self,
             records,
             extractor=None,
             is_order_natural=True):

        if not records:
            return records

        if not callable(extractor):
            self._record_extractor = lambda value: value
        else:
            self._record_extractor = extractor

        self._minimum_character_code = min(ord(self._record_extractor(character))
                                           for record in records
                                           for character in self._record_extractor(record))
        self._maximum_character_code = max(ord(self._record_extractor(character))
                                           for record in records
                                           for character in self._record_extractor(record))

        if is_order_natural:
            self._character_code_extractor = self._natural_code_extractor
        else:
            self._character_code_extractor = self._reverse_code_extractor

        sorted_records = self._radix_sort(records)

        self._record_extractor = None
        self._character_code_extractor = None
        self._minimum_character_code = None
        self._maximum_character_code = None

        return sorted_records


def alphabetical_lsd_radix_sort(records,
                                extractor=None,
                                is_order_natural=True):

    lsd_radix_sorter = AlphabeticalLSDRadixSorter()

    return lsd_radix_sorter.sort(records,
                                 extractor=extractor,
                                 is_order_natural=is_order_natural)


class RecursiveAlphabeticalMSDRadixSorter:

    def __init__(self):

        self._record_extractor = None
        self._character_code_extractor = None
        self._minimum_character_code = None
        self._maximum_character_code = None

    def _natural_code_extractor(self,
                                record,
                                index):

        raw_string = self._record_extractor(record)

        if index < len(raw_string):
            return 1 + ord(raw_string[index]) - self._minimum_character_code
        else:
            return 0

    def _reverse_code_extractor(self,
                                record,
                                index):

        raw_string = self._record_extractor(record)

        if index < len(raw_string):
            return self._maximum_character_code - ord(raw_string[index])
        else:
            return self._maximum_character_code - self._minimum_character_code + 1

    def _counting_sort(self,
                       records,
                       initial_index,
                       terminal_index,
                       character_index,
                       maximum_length):

        if initial_index >= terminal_index:
            return records

        range_size = (self._maximum_character_code - self._minimum_character_code + 2)

        number_to_count = [0] * range_size
        for record in records[initial_index: terminal_index + 1]:
            number = self._character_code_extractor(record, character_index)
            number_to_count[number] += 1

        for number in range(1, range_size):
            number_to_count[number] += number_to_count[number - 1]

        sorted_records = [None] * (terminal_index - initial_index + 1)
        for record in reversed(records[initial_index: terminal_index + 1]):
            number = self._character_code_extractor(record, character_index)
            number_to_count[number] -= 1
            sorted_index = number_to_count[number]
            sorted_records[sorted_index] = record

        records[initial_index: terminal_index + 1] = sorted_records

        if character_index >= maximum_length - 1:
            return records

        for number in range(1, range_size):
            records = self._counting_sort(records,
                                          initial_index + number_to_count[number - 1],
                                          initial_index + number_to_count[number] - 1,
                                          character_index + 1,
                                          maximum_length)
        records = self._counting_sort(records,
                                      initial_index + number_to_count[range_size - 1],
                                      terminal_index,
                                      character_index + 1,
                                      maximum_length)

        return records

    def _radix_sort(self,
                    records):

        maximum_length = max(len(self._record_extractor(record))
                             for record in records)

        if maximum_length == 0:
            return records

        records = self._counting_sort(records,
                                      0,
                                      len(records) - 1,
                                      0,
                                      maximum_length)

        return records

    def sort(self,
             records,
             extractor=None,
             is_order_natural=True):

        if not records:
            return records

        if not callable(extractor):
            self._record_extractor = lambda value: value
        else:
            self._record_extractor = extractor

        self._minimum_character_code = min(ord(self._record_extractor(character))
                                           for record in records
                                           for character in self._record_extractor(record))
        self._maximum_character_code = max(ord(self._record_extractor(character))
                                           for record in records
                                           for character in self._record_extractor(record))

        if is_order_natural:
            self._character_code_extractor = self._natural_code_extractor
        else:
            self._character_code_extractor = self._reverse_code_extractor

        sorted_records = self._radix_sort(records)

        self._record_extractor = None
        self._character_code_extractor = None
        self._minimum_character_code = None
        self._maximum_character_code = None

        return sorted_records


def recursive_alphabetical_msd_radix_sort(records,
                                          extractor=None,
                                          is_order_natural=True):

    msd_radix_sorter = RecursiveAlphabeticalMSDRadixSorter()

    return msd_radix_sorter.sort(records,
                                 extractor=extractor,
                                 is_order_natural=is_order_natural)


class IterativeAlphabeticalMSDRadixSorter:

    def __init__(self):

        self._record_extractor = None
        self._character_code_extractor = None
        self._minimum_character_code = None
        self._maximum_character_code = None

    def _natural_code_extractor(self,
                                record,
                                index):

        raw_string = self._record_extractor(record)

        if index < len(raw_string):
            return 1 + ord(raw_string[index]) - self._minimum_character_code
        else:
            return 0

    def _reverse_code_extractor(self,
                                record,
                                index):

        raw_string = self._record_extractor(record)

        if index < len(raw_string):
            return self._maximum_character_code - ord(raw_string[index])
        else:
            return self._maximum_character_code - self._minimum_character_code + 1

    def _counting_sort(self,
                       records,
                       maximum_length):

        range_size = (self._maximum_character_code - self._minimum_character_code + 2)

        stack = [(0, len(records) - 1, 0)]

        while stack:

            initial_index, terminal_index, character_index = stack.pop()

            number_to_count = [0] * range_size
            for record in records[initial_index: terminal_index + 1]:
                number = self._character_code_extractor(record, character_index)
                number_to_count[number] += 1

            for number in range(1, range_size):
                number_to_count[number] += number_to_count[number - 1]

            sorted_records = [None] * (terminal_index - initial_index + 1)
            for record in reversed(records[initial_index: terminal_index + 1]):
                number = self._character_code_extractor(record, character_index)
                number_to_count[number] -= 1
                sorted_index = number_to_count[number]
                sorted_records[sorted_index] = record

            records[initial_index: terminal_index + 1] = sorted_records

            if character_index < maximum_length - 1:

                for number in range(1, range_size):
                    new_initial_index = initial_index + number_to_count[number - 1]
                    new_terminal_index = initial_index + number_to_count[number] - 1
                    new_character_index = character_index + 1
                    if new_initial_index < new_terminal_index:
                        stack.append((new_initial_index, new_terminal_index, new_character_index))

                new_initial_index = initial_index + number_to_count[range_size - 1]
                new_terminal_index = terminal_index
                new_character_index = character_index + 1
                if new_initial_index < new_terminal_index:
                    stack.append((new_initial_index, new_terminal_index, new_character_index))

        return records

    def _radix_sort(self,
                    records):

        maximum_length = max(len(self._record_extractor(record))
                             for record in records)

        if maximum_length == 0:
            return records

        records = self._counting_sort(records,
                                      maximum_length)

        return records

    def sort(self,
             records,
             extractor=None,
             is_order_natural=True):

        if not records:
            return records

        if not callable(extractor):
            self._record_extractor = lambda value: value
        else:
            self._record_extractor = extractor

        self._minimum_character_code = min(ord(self._record_extractor(character))
                                           for record in records
                                           for character in self._record_extractor(record))
        self._maximum_character_code = max(ord(self._record_extractor(character))
                                           for record in records
                                           for character in self._record_extractor(record))

        if is_order_natural:
            self._character_code_extractor = self._natural_code_extractor
        else:
            self._character_code_extractor = self._reverse_code_extractor

        sorted_records = self._radix_sort(records)

        self._record_extractor = None
        self._character_code_extractor = None
        self._minimum_character_code = None
        self._maximum_character_code = None

        return sorted_records


def iterative_alphabetical_msd_radix_sort(records,
                                          extractor=None,
                                          is_order_natural=True):

    msd_radix_sorter = RecursiveAlphabeticalMSDRadixSorter()

    return msd_radix_sorter.sort(records,
                                 extractor=extractor,
                                 is_order_natural=is_order_natural)
