class RunLengthEncoder:

    def __init__(self):

        pass

    @staticmethod
    def compress(source_text):

        if not source_text:
            return source_text

        runs = []
        first_bit = source_text[0]
        if first_bit == '0':
            runs.append(first_bit)
        elif first_bit == '1':
            runs.append(first_bit)
        else:
            raise ValueError(f"an invalid bit in coded text: {first_bit}")

        count = 0
        for last_bit in source_text:
            if first_bit == '0' and last_bit == '0':
                count += 1
            elif first_bit == '1' and last_bit == '1':
                count += 1
            elif first_bit == '0' and last_bit == '1':
                run = '0' * (int(count).bit_length() - 1) + "{:b}".format(count)
                runs.append(run)
                count = 1
                first_bit = last_bit
            elif first_bit == '1' and last_bit == '0':
                run = '0' * (int(count).bit_length() - 1) + "{:b}".format(count)
                runs.append(run)
                count = 1
                first_bit = last_bit
            else:
                raise ValueError(f"an invalid bit in coded text: {last_bit}")

        if first_bit == '0':
            run = '0' * (int(count).bit_length() - 1) + "{:b}".format(count)
            runs.append(run)
        else:
            run = '0' * (int(count).bit_length() - 1) + "{:b}".format(count)
            runs.append(run)

        return ''.join(runs)

    @staticmethod
    def expand(coded_text):

        if not coded_text:
            return coded_text

        runs = []
        run_bit = coded_text[0]
        if run_bit != '0' and run_bit != '1':
            raise ValueError(f"an invalid bit in coded text: {run_bit}")

        index = 1
        while index < len(coded_text):

            zero_count = 0
            current_bit = coded_text[index]
            while current_bit == '0':
                zero_count += 1
                if index + zero_count < len(coded_text):
                    current_bit = coded_text[index + zero_count]
                else:
                    current_bit = ''

            if current_bit == '':
                raise ValueError("an invalid Elias gamma coded text")
            elif current_bit == '1' and run_bit == '0':
                run_length = int(coded_text[index + zero_count: index + 2 * zero_count + 1], 2)
                run = run_bit * run_length
                runs.append(run)
                run_bit = '1'
                index += 2 * zero_count + 1
            elif current_bit == '1' and run_bit == '1':
                run_length = int(coded_text[index + zero_count: index + 2 * zero_count + 1], 2)
                run = run_bit * run_length
                runs.append(run)
                run_bit = '0'
                index += 2 * zero_count + 1
            else:
                raise ValueError(f"an invalid bit in coded text: {current_bit}")

        return ''.join(runs)

    def calculate_compression_ratio(self,
                                    source_text):

        logarithmic_source_alphabet_size = int(2).bit_length() - 1
        source_text_size = len(source_text)

        logarithmic_coded_alphabet_size = int(2).bit_length() - 1
        coded_text_size = len(self.compress(source_text))

        return logarithmic_coded_alphabet_size * coded_text_size / (logarithmic_source_alphabet_size * source_text_size)
