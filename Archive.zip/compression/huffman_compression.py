from heaps import binary_heap


class HuffmanNode:

    def __init__(self,
                 character,
                 frequency,
                 left=None,
                 right=None):

        self._character = character
        self._frequency = frequency
        self._left = left
        self._right = right

    @property
    def character(self):

        return self._character

    @character.setter
    def character(self,
                  character):

        raise AttributeError("an immutable attribute 'character'")

    @property
    def frequency(self):

        return self._frequency

    @frequency.setter
    def frequency(self,
                  frequency):

        raise AttributeError("an immutable attribute 'frequency'")

    @property
    def left(self):

        return self._left

    @left.setter
    def left(self,
             left):

        raise AttributeError("an immutable attribute 'left'")

    @property
    def right(self):

        return self._right

    @right.setter
    def right(self,
              right):

        raise AttributeError("an immutable attribute 'right'")

    def is_node_leaf(self):

        return self._left is None and self._right is None


class HuffmanCompressor:

    def __init__(self):

        self._code_trie = None
        self._character_to_code = None

    def compress(self,
                 source_text):

        if not source_text:
            return source_text

        character_to_frequency = dict()
        for character in source_text:
            character_to_frequency[character] = character_to_frequency.get(character, 0) + 1

        self._character_to_code = dict()
        if len(character_to_frequency) == 1:

            character = source_text[0]
            self._character_to_code[character] = '0'
            self._code_trie = HuffmanNode(character, character_to_frequency[character])

        else:

            singleton_huffman_tries = [HuffmanNode(character, frequency)
                                       for character, frequency in character_to_frequency.items()]
            character_heap = binary_heap.BinaryHeap(singleton_huffman_tries,
                                                    key=lambda huffman_node: huffman_node.frequency)

            while len(character_heap) > 1:
                smaller_child_trie = character_heap.extract()
                larger_child_trie = character_heap.extract()
                if smaller_child_trie.frequency < larger_child_trie.frequency:
                    left_child_trie = smaller_child_trie
                    right_child_trie = larger_child_trie
                elif ord(smaller_child_trie.character) < ord(larger_child_trie.character):
                    left_child_trie = smaller_child_trie
                    right_child_trie = larger_child_trie
                else:
                    left_child_trie = larger_child_trie
                    right_child_trie = smaller_child_trie
                frequency = left_child_trie.frequency + right_child_trie.frequency
                parent_node = HuffmanNode(chr(0),
                                          frequency,
                                          left_child_trie,
                                          right_child_trie)
                character_heap.insert(parent_node)

            self._code_trie = character_heap.extract()
            stack = [(self._code_trie, '')]
            while stack:

                node, code = stack.pop()

                if node.is_node_leaf():
                    self._character_to_code[node.character] = code
                else:
                    stack.append((node.left, code + '0'))
                    stack.append((node.right, code + '1'))

        return ''.join(self._character_to_code[character]
                       for character in source_text)

    def expand(self,
               coded_text):

        if not self._character_to_code or not self._code_trie:
            raise ValueError("no Huffman trie available, compress data first")

        characters = []
        current_node = self._code_trie
        for bit in coded_text:

            if bit == '0':
                current_node = current_node.left
            elif bit == '1':
                current_node = current_node.right
            else:
                raise ValueError(f"an invalid bit in coded text: {bit}")

            if current_node.is_node_leaf():
                characters.append(current_node.character)
                current_node = self._code_trie

        if current_node != self._code_trie:
            raise ValueError("an invalid coded text as it does not match Huffman tree")

        return ''.join(characters)

    def calculate_compression_ratio(self,
                                    source_text):

        logarithmic_source_alphabet_size = (len(self._character_to_code)).bit_length() - 1
        source_text_size = len(source_text)

        logarithmic_coded_alphabet_size = int(2).bit_length() - 1
        coded_text_size = len(self.compress(source_text))

        return logarithmic_coded_alphabet_size * coded_text_size / (logarithmic_source_alphabet_size * source_text_size)

    @property
    def code_trie(self):

        return self._code_trie

    @code_trie.setter
    def code_trie(self,
                  code_trie):

        raise AttributeError("an immutable attribute 'code_trie'")

    @property
    def character_to_code(self):

        return self._character_to_code

    @character_to_code.setter
    def character_to_code(self,
                          character_to_code):

        raise AttributeError("an immutable attribute 'character_to_code'")
