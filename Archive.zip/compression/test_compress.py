import pytest
import random
import string

import huffman_compression
import run_length_encoding


@pytest.fixture
def words():

    return [''.join(random.choices(string.ascii_letters,
                                   k=random.randint(5, 15)))
            for _ in range(1000000)]


@pytest.fixture
def source_text(words):

    return ' '.join(words)


@pytest.fixture
def binary_source_text(words):

    return ''.join(random.choices(['0', '1'],
                                  k=100000000))


def test_huffman_compression(source_text):

    huffman_compressor = huffman_compression.HuffmanCompressor()
    compressed_text = huffman_compressor.compress(source_text)
    expanded_text = huffman_compressor.expand(compressed_text)

    assert source_text == expanded_text


def test_run_length_encoding(binary_source_text):

    run_length_encoder = run_length_encoding.RunLengthEncoder()
    compressed_text = run_length_encoder.compress(binary_source_text)
    expanded_text = run_length_encoder.expand(compressed_text)

    assert binary_source_text == expanded_text
