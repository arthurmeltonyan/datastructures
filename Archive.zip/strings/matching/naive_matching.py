def naive_match(text,
                pattern):

    n = len(text)
    m = len(pattern)

    for text_index in range(0, n - m):
        pattern_index = 0
        while pattern_index < m and text[text_index + pattern_index] == pattern[pattern_index]:
            pattern_index += 1
        if pattern_index == m:
            return text_index

    return -1
