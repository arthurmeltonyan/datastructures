def ac_match(text,
              pattern):

    pass

    return []
