def kmp_match(text,
              pattern):

    m = len(pattern)
    prefix_length = 0
    prefix_table = [0] * m

    for pattern_index in range(1, m):
        if pattern[pattern_index] == pattern[prefix_length]:
            prefix_length += 1
            prefix_table[pattern_index] = prefix_length
            pattern_index += 1
        elif prefix_length == 0:
            prefix_table[pattern_index] = 0
            pattern_index += 1
        else:
            prefix_length = prefix_table[prefix_length - 1]

    n = len(text)
    text_index = 0
    pattern_index = 0

    while text_index < n:
        if text[text_index] == pattern[pattern_index]:
            text_index += 1
            pattern_index += 1
            if pattern_index == m:
                return text_index - m
        elif pattern_index == 0:
            text_index += 1
        else:
            pattern_index = prefix_table[pattern_index]

    return -1
