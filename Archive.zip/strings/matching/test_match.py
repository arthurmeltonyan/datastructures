import pytest
import random
import string

import naive_matching
import kmp_matching


@pytest.fixture
def words():

    return [''.join(random.choices(string.ascii_letters,
                                   k=random.randint(5, 15)))
            for _ in range(1000000)]


@pytest.fixture
def text(words):

    return ' '.join(words)


@pytest.fixture
def present_pattern(words):

    index = random.randint(0, len(words) - 1)
    return words[index]


@pytest.fixture
def absent_pattern():

    return ''.join(random.choices(string.ascii_letters,
                                  k=20))


class TestNaiveMatching:

    @staticmethod
    def test_present(text,
                     present_pattern):

        index = naive_matching.naive_match(text,
                                           present_pattern)
        assert index == text.find(present_pattern)

    @staticmethod
    def test_absent(text,
                    absent_pattern):

        index = naive_matching.naive_match(text,
                                           absent_pattern)
        assert index == text.find(absent_pattern)


class TestKMPMatching:

    @staticmethod
    def test_present(text,
                     present_pattern):

        index = kmp_matching.kmp_match(text,
                                       present_pattern)
        assert index == text.find(present_pattern)

    @staticmethod
    def test_absent(text,
                    absent_pattern):

        index = kmp_matching.kmp_match(text,
                                       absent_pattern)
        assert index == text.find(absent_pattern)
