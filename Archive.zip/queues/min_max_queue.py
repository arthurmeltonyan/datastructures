import simple_queue as sq


class MinMaxQueue(sq.SimpleQueue):

    def __init__(self,
                 values=None,
                 key=None):

        super().__init__(values)

        if not callable(key):
            self._key = lambda value: value
        else:
            self._key = key

        self._mode = 'minimum-maximum'

        self._minimum_queue = sq.SimpleQueue()
        self._maximum_queue = sq.SimpleQueue()

    def __str__(self):

        if not self:
            return f"Min-Max Queue ()"
        else:
            return f"Min-Max Queue (first={self.front}, minimum={self.minimum}, maximum={self.maximum})"

    def __setitem__(self,
                    index,
                    value):

        if not self:
            raise ValueError("an empty queue")
        elif 0 <= index <= self._size - 1:
            old_values = [self.pop()
                          for _ in range(0, index + 1)]
            self.push(value)
            for old_value in old_values:
                self.push(old_value)
        else:
            raise IndexError("an index out of range")

    def _is_smaller_than_minimum(self,
                                 value):

        minimum_key = self._key(self.minimum)
        new_key = self._key(value)

        return new_key < minimum_key

    def _is_larger_than_maximum(self,
                                value):

        maximum_key = self._key(self.maximum)
        new_key = self._key(value)

        return new_key > maximum_key

    def push(self,
             value):

        if not self:
            super().push(value)
            self._minimum_queue.push(value)
            self._maximum_queue.push(value)
        elif self._is_smaller_than_minimum(value):
            super().push(value)
            self._minimum_queue.push(value)
            self._maximum_queue.push(self.maximum)
        elif self._is_larger_than_maximum(value):
            super().push(value)
            self._minimum_queue.push(self.minimum)
            self._maximum_queue.push(value)
        else:
            super().push(value)
            self._minimum_queue.push(self.minimum)
            self._maximum_queue.push(self.maximum)

    def pop(self,
            index=0):

        if not self:
            raise ValueError("an empty queue")
        elif 0 <= index <= self._size - 1:
            old_values = []
            for _ in range(0, index + 1):
                old_value = super().pop()
                self._minimum_queue.pop()
                self._maximum_queue.pop()
                old_values.append(old_value)
            value = old_values.pop()
            for old_value in old_values:
                self.push(old_value)
            return value
        else:
            raise IndexError("an index out of range")

    @property
    def minimum(self):

        if not self:
            raise ValueError("an empty queue")
        else:
            return self._minimum_queue.front

    @property
    def maximum(self):

        if not self:
            raise ValueError("an empty queue")
        else:
            return self._maximum_queue.front

    @property
    def key(self):

        return self._key

    @key.setter
    def key(self,
            key):

        raise AttributeError("an immutable attribute 'key'")

    @property
    def mode(self):

        return self._mode

    @mode.setter
    def mode(self,
             mode):

        raise AttributeError("an immutable attribute 'mode'")

    @property
    def minimum_queue(self):

        return self._minimum_queue

    @minimum_queue.setter
    def minimum_queue(self,
                      minimum_queue):

        raise AttributeError("an immutable attribute 'minimum_queue'")

    @property
    def maximum_queue(self):

        return self._maximum_queue

    @maximum_queue.setter
    def maximum_queue(self,
                      maximum_queue):

        raise AttributeError("an immutable attribute 'maximum_queue'")
