class MultiwayPrefixNode:

    def __init__(self,
                 value=None,
                 children=None,
                 is_text_complete=False):

        self._value = value

        if children is None:
            self._children = dict()
        else:
            self._children = children

        self._is_text_complete = is_text_complete

    @property
    def value(self):

        return self._value

    @value.setter
    def value(self,
              value):

        self._value = value

    @property
    def children(self):

        return self._children

    @children.setter
    def children(self,
                 children):

        self._children = children

    @property
    def is_text_complete(self):

        return self._is_text_complete

    @is_text_complete.setter
    def is_text_complete(self,
                         is_text_complete):

        self._is_text_complete = is_text_complete


class MultiwayPrefixTree:

    def __init__(self,
                 texts=None):

        self._root_node = MultiwayPrefixNode()
        self._text_count = 0

        if texts is not None:
            for text in texts:
                self.insert(text)

    def __str__(self):

        if self._text_count == 0:
            return f"Multiway Prefix Tree ()"
        else:
            return f"Multiway Prefix Tree (text_count={self._text_count})"

    def __bool__(self):

        return self._text_count > 0

    def __len__(self):

        return self._text_count

    def __contains__(self,
                     text):

        current_node = self._root_node
        for character in text:
            if character not in current_node.children:
                return False
            else:
                current_node = current_node.children[character]

        return current_node.is_text_complete

    def insert(self,
               text,
               value=None):

        current_node = self._root_node
        for character in text:
            if character not in current_node.children:
                current_node.children[character] = MultiwayPrefixNode()
            current_node = current_node.children[character]

        if not current_node.is_text_complete:
            self._text_count += 1

        current_node.is_text_complete = True
        current_node.value = value

    def _extract(self,
                 node,
                 text,
                 index):

        if index == len(text):
            node.is_text_complete = False
            return len(node.children) == 0
        else:
            next_character = text[index]
            next_node = node.children[next_character]
            is_next_node_deleted = self._extract(next_node,
                                                 text,
                                                 index + 1)
            if is_next_node_deleted:
                next_character = text[index]
                node.children.pop(next_character)
            return (is_next_node_deleted
                    and node.is_text_complete
                    and len(node.children) == 0)

    def extract(self,
                text):

        if text in self:
            self._extract(self._root_node,
                          text,
                          0)

    @property
    def root_node(self):

        return self._root_node

    @root_node.setter
    def root_node(self,
                  root_node):

        raise AttributeError("an immutable attribute 'root_node'")

    @property
    def text_count(self):

        return self._text_count

    @text_count.setter
    def text_count(self,
                   text_count):

        raise AttributeError("an immutable attribute 'text_count'")
