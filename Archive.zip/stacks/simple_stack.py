class SimpleStackNode:

    def __init__(self,
                 value,
                 below=None):

        self._value = value
        self._below = below

    @property
    def value(self):

        return self._value

    @value.setter
    def value(self,
              value):

        self._value = value

    @property
    def below(self):

        return self._below

    @below.setter
    def below(self,
              below):

        self._below = below


class SimpleStack:

    def __init__(self,
                 values=None):

        self._size = 0
        self._top_pointer = None
        if values is not None:
            for value in values:
                self.push(value)

    def __str__(self):

        if not self:
            return f"Simple Stack ()"
        else:
            return f"Simple Stack (last={self.top})"

    def __bool__(self):

        return bool(self._top_pointer)

    def __len__(self):

        return self._size

    def __iter__(self):

        current_pointer = self._top_pointer
        while current_pointer:
            yield current_pointer.value
            current_pointer = current_pointer.below

    def __contains__(self,
                     value):

        current_pointer = self._top_pointer
        while current_pointer:
            if current_pointer.value == value:
                return True
            current_pointer = current_pointer.below
        return False

    def __getitem__(self,
                    index):

        if not self:
            raise ValueError("an empty stack")
        elif 0 <= index <= self._size - 1:
            current_pointer = self._top_pointer
            for _ in range(0, index):
                current_pointer = current_pointer.below

            value = current_pointer.value
            return value
        else:
            raise IndexError("an index out of range")

    def __setitem__(self,
                    index,
                    value):

        if not self:
            raise ValueError("an empty stack")
        elif 0 <= index <= self._size - 1:
            current_pointer = self._top_pointer
            for _ in range(0, index):
                current_pointer = current_pointer.below

            current_pointer.value = value
        else:
            raise IndexError("an index out of range")

    def __delitem__(self,
                    index):

        self.pop(index)

    def push(self,
             value):

        if not self:
            new_node = SimpleStackNode(value,
                                       None)

            self._top_pointer = new_node
            self._size += 1
        else:
            new_node = SimpleStackNode(value,
                                       self._top_pointer)

            self._top_pointer = new_node
            self._size += 1

    def pop(self,
            index=0):

        if not self:
            raise ValueError("an empty stack")
        elif self._size == 1 and index == 0:
            value = self._top_pointer.value

            self._top_pointer = None
            self._size -= 1
            return value
        elif index == 0:
            value = self._top_pointer.value

            self._top_pointer = self._top_pointer.below
            self._size -= 1
            return value
        elif 0 < index <= self._size - 1:
            current_pointer = self._top_pointer
            previous_pointer = current_pointer
            for _ in range(0, index):
                previous_pointer = current_pointer
                current_pointer = current_pointer.below

            value = current_pointer.value
            previous_pointer.below = current_pointer.below

            self._size -= 1
            return value
        else:
            raise IndexError("an index out of range")

    @property
    def top(self):

        if not self:
            raise ValueError("an empty stack")
        else:
            return self._top_pointer.value

    @property
    def size(self):

        return self._size

    @size.setter
    def size(self,
             size):

        raise AttributeError("an immutable attribute 'size'")

    @property
    def top_pointer(self):

        return self._top_pointer

    @top_pointer.setter
    def top_pointer(self,
                    top_pointer):

        raise AttributeError("an immutable attribute 'top_pointer'")
