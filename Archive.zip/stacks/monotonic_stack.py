import simple_stack as ss


class MonotonicStack(ss.SimpleStack):

    def __init__(self,
                 values=None,
                 key=None,
                 mode='minimum'):

        super().__init__(values)

        if not callable(key):
            self._key = lambda value: value
        else:
            self._key = key

        if mode == 'minimum':
            self._mode = 'minimum'
        elif mode == 'minimum+':
            self._mode = 'minimum+'
        elif mode == 'maximum':
            self._mode = 'maximum'
        elif mode == 'maximum+':
            self._mode = 'maximum+'
        else:
            raise ValueError("an invalid 'mode' value")

    def __str__(self):

        if not self and self._mode == 'minimum':
            return f"Monotonic Strictly Increasing Stack ()"
        elif self and self._mode == 'minimum':
            return f"Monotonic Strictly Increasing Stack (last={self.top})"
        elif not self and self._mode == 'minimum+':
            return f"Monotonic Weakly Increasing Stack ()"
        elif self and self._mode == 'minimum+':
            return f"Monotonic Weakly Increasing Stack (last={self.top})"
        elif not self and self._mode == 'maximum':
            return f"Monotonic Strictly Decreasing Stack ()"
        elif self and self._mode == 'maximum':
            return f"Monotonic Strictly Decreasing Stack (last={self.top})"
        elif not self and self._mode == 'maximum+':
            return f"Monotonic Weakly Decreasing Stack ()"
        elif self and self._mode == 'maximum+':
            return f"Monotonic Weakly Decreasing Stack (last={self.top})"
        else:
            raise ValueError("an invalid 'mode' value")

    def __setitem__(self,
                    index,
                    value):

        if not self:
            raise ValueError("an empty stack")
        elif 0 <= index <= self._size - 1:
            old_values = []
            for _ in range(0, index + 1):
                old_value = super().pop()
                old_values.append(old_value)
            self.push(value)
            for old_value in old_values:
                self.push(old_value)
        else:
            raise IndexError("an index out of range")

    def _is_sequence_strictly_increasing(self,
                                         value):

        if not self:
            return True
        else:
            old_key = self._key(self.top)
            new_key = self._key(value)

            return old_key < new_key

    def _is_sequence_non_strictly_increasing(self,
                                             value):

        if not self:
            return True
        else:
            old_key = self._key(self.top)
            new_key = self._key(value)

            return old_key <= new_key

    def _is_sequence_strictly_decreasing(self,
                                         value):

        if not self:
            return True
        else:
            old_key = self._key(self.top)
            new_key = self._key(value)

            return old_key > new_key

    def _is_sequence_non_strictly_decreasing(self,
                                             value):

        if not self:
            return True
        else:
            old_key = self._key(self.top)
            new_key = self._key(value)

            return old_key >= new_key

    def _is_stack_strictly_increasing(self):

        return self._mode == 'minimum'

    def _is_stack_non_strictly_increasing(self):

        return self._mode == 'minimum+'

    def _is_stack_strictly_decreasing(self):

        return self._mode == 'maximum'

    def _is_stack_non_strictly_decreasing(self):

        return self._mode == 'maximum+'

    def push(self,
             value):

        if not self:
            super().push(value)
        elif self._is_stack_strictly_increasing():
            while not self._is_sequence_strictly_increasing(value):
                super().pop()
            super().push(value)
        elif self._is_stack_non_strictly_increasing():
            while not self._is_sequence_non_strictly_increasing(value):
                self.pop()
            super().push(value)
        elif self._is_stack_strictly_decreasing():
            while not self._is_sequence_strictly_decreasing(value):
                self.pop()
            super().push(value)
        elif self._is_stack_non_strictly_decreasing():
            while not self._is_sequence_non_strictly_decreasing(value):
                self.pop()
            super().push(value)
        else:
            raise ValueError("an invalid 'mode' value")

    def pop(self,
            index=0):

        if not self:
            raise ValueError("an empty stack")
        elif 0 <= index <= self._size - 1:
            old_values = []
            for _ in range(0, index + 1):
                old_value = super().pop()
                old_values.append(old_value)
            value = old_values.pop()
            for old_value in old_values:
                self.push(old_value)
            return value
        else:
            raise IndexError("an index out of range")

    @property
    def key(self):

        return self._key

    @key.setter
    def key(self,
            key):

        raise AttributeError("an immutable attribute 'key'")

    @property
    def mode(self):

        return self._mode

    @mode.setter
    def mode(self,
             mode):

        raise AttributeError("an immutable attribute 'mode'")
