def single_linear_search(records,
                         target,
                         extractor=None):

    if not callable(extractor):
        extractor = lambda value: value

    for index, record in enumerate(records):
        extracted_value = extractor(record)
        if extracted_value == target:
            return index

    return -1
