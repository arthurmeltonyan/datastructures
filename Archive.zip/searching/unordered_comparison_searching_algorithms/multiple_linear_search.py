def multiple_linear_search(records,
                           targets,
                           extractor=None):

    if not callable(extractor):
        extractor = lambda record: record

    targets = set(targets)
    target_to_index = {target: -1
                       for target in targets}

    for index in range(records):
        extracted_value = extractor(records[index])
        if extracted_value in targets:
            targets.discard(extracted_value)
            target_to_index[extracted_value] = index
        if not targets:
            return target_to_index

    return target_to_index
