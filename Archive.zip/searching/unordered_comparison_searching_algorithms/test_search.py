import pytest
import random

import single_linear_search
import multiple_linear_search


@pytest.fixture
def records():

    return [random.randint(-1000000, 1000000)
            for _ in range(1000000)]


@pytest.fixture
def present_target(records):

    return random.choice(records)


@pytest.fixture
def present_target_count():

    return 100


@pytest.fixture
def present_targets(records,
                    present_target_count):

    return random.sample(records,
                         present_target_count)


@pytest.fixture
def absent_target(records):

    return max(records) + 1


@pytest.fixture
def absent_target_count():

    return 100


@pytest.fixture
def absent_targets(records,
                   absent_target_count):

    max_record = max(records) + 1

    return [max_record + index
            for index in range(absent_target_count)]


@pytest.fixture
def present_indices(records,
                    present_target):

    indices = []
    for index, record in enumerate(records):
        if record == present_target:
            indices.append(index)

    return indices


@pytest.fixture
def present_target_to_present_indices(records,
                                      present_targets):

    present_targets = set(present_targets)
    target_to_indices = {target: []
                         for target in present_targets}

    for index, record in enumerate(records):
        if record in present_targets:
            target_to_indices[record].append(index)

    return target_to_indices


@pytest.fixture
def absent_index(records):

    return -1


@pytest.fixture
def absent_target_to_absent_index(records,
                                  absent_targets):

    target_to_indices = {target: -1
                         for target in absent_targets}

    return target_to_indices


class TestSingleLinearSearch:

    @staticmethod
    def test_present(records,
                     present_target,
                     present_indices):

        index = single_linear_search.single_linear_search(records, present_target)
        assert index in present_indices

    @staticmethod
    def test_absent(records,
                    absent_target,
                    absent_index):

        index = single_linear_search.single_linear_search(records, absent_target)
        assert index == absent_index


class TestMultipleLinearSearch:

    @staticmethod
    def test_present(records,
                     present_targets,
                     present_target_to_present_indices):

        target_to_index = multiple_linear_search.multiple_linear_search(records, present_targets)
        assert all(target_to_index[target] in present_target_to_present_indices[target]
                   for target in present_targets)

    @staticmethod
    def test_absent(records,
                    absent_targets,
                    absent_target_to_absent_index):

        target_to_index = multiple_linear_search.multiple_linear_search(records, absent_targets)
        assert all(target_to_index[target] == absent_target_to_absent_index[target]
                   for target in absent_targets)

    @staticmethod
    def test_mixed(records,
                   present_targets,
                   present_target_to_present_indices,
                   absent_targets,
                   absent_target_to_absent_index):

        target_to_index = multiple_linear_search.multiple_linear_search(records, present_targets + absent_targets)
        assert all(target_to_index[target] in present_target_to_present_indices[target]
                   if target in present_target_to_present_indices
                   else target_to_index[target] == absent_target_to_absent_index[target]
                   for target in present_targets)
