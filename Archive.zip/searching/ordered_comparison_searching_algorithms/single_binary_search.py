def single_binary_search(records,
                         target,
                         extractor=None):

    if not records:
        return -1

    if not callable(extractor) and records[0] < records[-1]:
        record_extractor = lambda record: record
    elif not callable(extractor):
        record_extractor = lambda record: -record
        target *= -1
    elif extractor(records[0]) < extractor(records[-1]):
        record_extractor = lambda record: extractor(record)
    else:
        record_extractor = lambda record: -extractor(record)
        target *= -1

    lower_index = 0
    upper_index = len(records) - 1

    while lower_index < upper_index:

        middle_index = lower_index + (upper_index - lower_index) // 2
        middle_key = record_extractor(records[middle_index])
        if target > middle_key:
            lower_index = middle_index + 1
        else:
            upper_index = middle_index

    lower_key = record_extractor(records[lower_index])
    if target == lower_key:
        return lower_index
    else:
        return -1
