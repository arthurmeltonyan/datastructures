from sorting.comparison_sorting_algorithms import peek_sort


class RecursiveMultipleBinarySearcher:

    def __init__(self):

        self._record_extractor = None
        self._target_transformer = None

    def _binary_search(self,
                       records,
                       initial_index,
                       terminal_index,
                       target):

        target = self._target_transformer(target)

        lower_index = initial_index
        upper_index = terminal_index

        while lower_index < upper_index:

            middle_index = lower_index + (upper_index - lower_index) // 2
            middle_key = self._record_extractor(records[middle_index])
            if target > middle_key:
                lower_index = middle_index + 1
            else:
                upper_index = middle_index

        lower_key = self._record_extractor(records[lower_index])
        if target == lower_key:
            return True, lower_index
        elif self._record_extractor(records[0]) < self._record_extractor(records[-1]):
            return False, lower_index
        else:
            return False, upper_index

    def _search(self,
                records,
                initial_index,
                terminal_index,
                targets,
                left_index,
                right_index,
                target_to_index):

        if left_index > right_index:
            return []
        elif initial_index > terminal_index:
            return []
        elif initial_index == terminal_index:
            indices = [initial_index
                       for index in range(left_index, right_index + 1)
                       if self._record_extractor(records[initial_index]) == self._target_transformer(targets[index])]
            return indices

        middle_index = left_index + (right_index - left_index) // 2

        if self._target_transformer(targets[middle_index]) > self._record_extractor(records[terminal_index]):
            return self._search(records,
                                initial_index,
                                terminal_index,
                                targets,
                                left_index,
                                middle_index - 1,
                                target_to_index)
        elif self._target_transformer(targets[middle_index]) < self._record_extractor(records[initial_index]):
            return self._search(records,
                                initial_index,
                                terminal_index,
                                targets,
                                middle_index + 1,
                                right_index,
                                target_to_index)
        else:
            indices = []
            is_target_found, index = self._binary_search(records,
                                                         initial_index,
                                                         terminal_index,
                                                         targets[middle_index])

            if is_target_found:
                target = targets[middle_index]
                target_to_index[target] = index
                left_indices = self._search(records,
                                            initial_index,
                                            index - 1,
                                            targets,
                                            left_index,
                                            middle_index - 1,
                                            target_to_index)
                indices.extend(left_indices)
                right_indices = self._search(records,
                                             index + 1,
                                             terminal_index,
                                             targets,
                                             middle_index + 1,
                                             right_index,
                                             target_to_index)
                indices.extend(right_indices)
            elif self._record_extractor(records[0]) < self._record_extractor(records[-1]):
                left_indices = self._search(records,
                                            initial_index,
                                            index - 1,
                                            targets,
                                            left_index,
                                            middle_index - 1,
                                            target_to_index)
                indices.extend(left_indices)
                right_indices = self._search(records,
                                             index,
                                             terminal_index,
                                             targets,
                                             middle_index + 1,
                                             right_index,
                                             target_to_index)
                indices.extend(right_indices)
            else:
                left_indices = self._search(records,
                                            initial_index,
                                            index,
                                            targets,
                                            left_index,
                                            middle_index - 1,
                                            target_to_index)
                indices.extend(left_indices)
                right_indices = self._search(records,
                                             index + 1,
                                             terminal_index,
                                             targets,
                                             middle_index + 1,
                                             right_index,
                                             target_to_index)
                indices.extend(right_indices)

        return indices

    def search(self,
               records,
               targets,
               extractor=None):

        if not records:
            return []
        elif not targets:
            return []

        target_to_index = {target: -1
                           for target in targets}

        if not callable(extractor) and records[0] < records[-1]:

            self._record_extractor = lambda record: record
            self._target_transformer = lambda target: target
            targets = peek_sort.peek_sort(targets,
                                          is_order_natural=True)
            self._search(records,
                         0,
                         len(records) - 1,
                         targets,
                         0,
                         len(targets) - 1,
                         target_to_index)

            return target_to_index

        elif not callable(extractor):

            self._record_extractor = lambda record: -record
            self._target_transformer = lambda target: -target
            targets = peek_sort.peek_sort(targets,
                                          is_order_natural=False)
            self._search(records,
                         0,
                         len(records) - 1,
                         targets,
                         0,
                         len(targets) - 1,
                         target_to_index)

            return target_to_index

        elif extractor(records[0]) < extractor(records[-1]):

            self._record_extractor = lambda record: extractor(record)
            self._target_transformer = lambda target: target
            targets = peek_sort.peek_sort(targets,
                                          is_order_natural=True)
            self._search(records,
                         0,
                         len(records) - 1,
                         targets,
                         0,
                         len(targets) - 1,
                         target_to_index)

            return target_to_index

        else:

            self._record_extractor = lambda record: -extractor(record)
            self._target_transformer = lambda target: -target
            targets = peek_sort.peek_sort(targets,
                                          is_order_natural=False)
            self._search(records,
                         0,
                         len(records) - 1,
                         targets,
                         0,
                         len(targets) - 1,
                         target_to_index)

            return target_to_index


def recursive_multiple_binary_search(records,
                                     targets,
                                     extractor=None):

    multiple_binary_searcher = RecursiveMultipleBinarySearcher()

    return multiple_binary_searcher.search(records,
                                           targets,
                                           extractor=extractor)
