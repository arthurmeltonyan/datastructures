import pytest
import random

import single_binary_search
import multiple_binary_search
import exponential_search


@pytest.fixture
def records():

    return [random.randint(-1000000, 1000000)
            for _ in range(1000000)]


@pytest.fixture
def naturally_sorted_records(records):

    return sorted(records,
                  reverse=False)


@pytest.fixture
def reversely_sorted_records(naturally_sorted_records):

    return naturally_sorted_records[::-1]


@pytest.fixture
def present_target(records):

    return random.choice(records)


@pytest.fixture
def present_target_count():

    return 100


@pytest.fixture
def present_targets(records,
                    present_target_count):

    return random.sample(records,
                         present_target_count)


@pytest.fixture
def absent_target(naturally_sorted_records):

    return naturally_sorted_records[0] - 1


@pytest.fixture
def absent_target_count():

    return 100


@pytest.fixture
def absent_targets(naturally_sorted_records,
                   absent_target_count):

    min_record = naturally_sorted_records[0] - 1

    return [min_record - index
            for index in range(0, absent_target_count)]


@pytest.fixture
def naturally_sorted_present_first_index(naturally_sorted_records,
                                         present_target):

    for index, record in enumerate(naturally_sorted_records):
        if record == present_target:
            return index


@pytest.fixture
def naturally_sorted_present_last_index(naturally_sorted_records,
                                        present_target):

    for index, record in enumerate(naturally_sorted_records[::-1]):
        if record == present_target:
            return len(naturally_sorted_records) - 1 - index


@pytest.fixture
def naturally_sorted_present_target_to_present_range(naturally_sorted_records,
                                                     present_targets):
    present_targets = set(present_targets)
    target_to_range = {target: []
                       for target in present_targets}

    for index, record in enumerate(naturally_sorted_records):
        if record in present_targets:
            if not target_to_range[record]:
                target_to_range[record] = [index, index]
            else:
                target_to_range[record][1] = index

    return target_to_range


@pytest.fixture
def reversely_sorted_present_first_index(reversely_sorted_records,
                                         present_target):

    for index, record in enumerate(reversely_sorted_records):
        if record == present_target:
            return index


@pytest.fixture
def reversely_sorted_present_last_index(reversely_sorted_records,
                                        present_target):

    for index, record in enumerate(reversely_sorted_records[::-1]):
        if record == present_target:
            return len(reversely_sorted_records) - 1 - index


@pytest.fixture
def reversely_sorted_present_target_to_present_range(reversely_sorted_records,
                                                     present_targets):

    present_targets = set(present_targets)
    target_to_range = {target: []
                       for target in present_targets}

    for index, record in enumerate(reversely_sorted_records):
        if record in present_targets:
            if not target_to_range[record]:
                target_to_range[record] = [index, index]
            else:
                target_to_range[record][1] = index

    return target_to_range


@pytest.fixture
def absent_index(records,
                 absent_target):

    return -1


@pytest.fixture
def absent_target_to_absent_index(records,
                                  absent_targets):

    target_to_indices = {target: -1
                         for target in absent_targets}

    return target_to_indices


class TestSingleBinarySearch:

    @staticmethod
    def test_present_natural(naturally_sorted_records,
                             present_target,
                             naturally_sorted_present_first_index,
                             naturally_sorted_present_last_index):

        index = single_binary_search.single_binary_search(naturally_sorted_records,
                                                          present_target)
        assert naturally_sorted_present_first_index <= index <= naturally_sorted_present_last_index

    @staticmethod
    def test_absent_natural(naturally_sorted_records,
                            absent_target,
                            absent_index):

        index = single_binary_search.single_binary_search(naturally_sorted_records,
                                                          absent_target)
        assert index == absent_index

    @staticmethod
    def test_present_reverse(reversely_sorted_records,
                             present_target,
                             reversely_sorted_present_first_index,
                             reversely_sorted_present_last_index):

        index = single_binary_search.single_binary_search(reversely_sorted_records,
                                                          present_target)
        assert reversely_sorted_present_first_index <= index <= reversely_sorted_present_last_index

    @staticmethod
    def test_absent_reverse(reversely_sorted_records,
                            absent_target,
                            absent_index):

        index = single_binary_search.single_binary_search(reversely_sorted_records,
                                                          absent_target)
        assert index == absent_index


class TestMultipleBinarySearch:

    @staticmethod
    def test_present_natural(naturally_sorted_records,
                             present_targets,
                             naturally_sorted_present_target_to_present_range):

        target_to_range = naturally_sorted_present_target_to_present_range
        target_to_index = multiple_binary_search.recursive_multiple_binary_search(naturally_sorted_records,
                                                                                  present_targets)
        assert all(target_to_range[target][0] <= target_to_index[target] <= target_to_range[target][1]
                   for target in present_targets)

    @staticmethod
    def test_present_reverse(reversely_sorted_records,
                             present_targets,
                             reversely_sorted_present_target_to_present_range):

        target_to_range = reversely_sorted_present_target_to_present_range
        target_to_index = multiple_binary_search.recursive_multiple_binary_search(reversely_sorted_records,
                                                                                  present_targets)
        assert all(target_to_range[target][0] <= target_to_index[target] <= target_to_range[target][1]
                   for target in present_targets)

    @staticmethod
    def test_absent_natural(naturally_sorted_records,
                            absent_targets,
                            absent_target_to_absent_index):

        target_to_index = multiple_binary_search.recursive_multiple_binary_search(naturally_sorted_records,
                                                                                  absent_targets)
        assert all(target_to_index[target] == absent_target_to_absent_index[target]
                   for target in absent_targets)

    @staticmethod
    def test_absent_reverse(reversely_sorted_records,
                            absent_targets,
                            absent_target_to_absent_index):

        target_to_index = multiple_binary_search.recursive_multiple_binary_search(reversely_sorted_records,
                                                                                  absent_targets)
        assert all(target_to_index[target] == absent_target_to_absent_index[target]
                   for target in absent_targets)

    @staticmethod
    def test_mixed_natural(naturally_sorted_records,
                           present_targets,
                           naturally_sorted_present_target_to_present_range,
                           absent_targets,
                           absent_target_to_absent_index):

        target_to_range = naturally_sorted_present_target_to_present_range
        target_to_index = multiple_binary_search.recursive_multiple_binary_search(naturally_sorted_records,
                                                                                  present_targets + absent_targets)
        assert all(target_to_range[target][0] <= target_to_index[target] <= target_to_range[target][1]
                   if target in target_to_range
                   else target_to_index[target] == absent_target_to_absent_index[target]
                   for target in present_targets)

    @staticmethod
    def test_mixed_reverse(reversely_sorted_records,
                           present_targets,
                           reversely_sorted_present_target_to_present_range,
                           absent_targets,
                           absent_target_to_absent_index):

        target_to_range = reversely_sorted_present_target_to_present_range
        target_to_index = multiple_binary_search.recursive_multiple_binary_search(reversely_sorted_records,
                                                                                  present_targets + absent_targets)
        assert all(target_to_range[target][0] <= target_to_index[target] <= target_to_range[target][1]
                   if target in target_to_range
                   else target_to_index[target] == absent_target_to_absent_index[target]
                   for target in present_targets)


class TestExponentialSearch:

    @staticmethod
    def test_present_natural(naturally_sorted_records,
                             present_target,
                             naturally_sorted_present_first_index,
                             naturally_sorted_present_last_index):
        index = exponential_search.exponential_search(naturally_sorted_records,
                                                      present_target)
        assert naturally_sorted_present_first_index <= index <= naturally_sorted_present_last_index

    @staticmethod
    def test_absent_natural(naturally_sorted_records,
                            absent_target,
                            absent_index):
        index = exponential_search.exponential_search(naturally_sorted_records,
                                                      absent_target)
        assert index == absent_index

    @staticmethod
    def test_present_reverse(reversely_sorted_records,
                             present_target,
                             reversely_sorted_present_first_index,
                             reversely_sorted_present_last_index):

        index = exponential_search.exponential_search(reversely_sorted_records,
                                                      present_target)
        assert reversely_sorted_present_first_index <= index <= reversely_sorted_present_last_index

    @staticmethod
    def test_absent_reverse(reversely_sorted_records,
                            absent_target,
                            absent_index):

        index = exponential_search.exponential_search(reversely_sorted_records,
                                                      absent_target)
        assert index == absent_index
