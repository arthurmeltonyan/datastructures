class BinaryMinMaxPairHeap:

    def __init__(self,
                 records=None,
                 extractor=None,
                 terminal_record=None):

        if not callable(extractor):
            self._extractor = lambda value: value
        else:
            self._extractor = extractor

        self._terminal_record = terminal_record

        if records is None:
            self._records = []
        else:
            self._records = list(records)
            if len(self._records) % 2 > 0:
                self._records.append(self._terminal_record)
            for node_index in range(len(self._records) // 2 - 1, -1, -1):
                self._bubble_down(node_index)

    def __str__(self):

        if not self:
            return f"Binary Min-Max-Pair Heap (): []"
        else:
            return f"Binary Min-Max-Pair Heap (minimum={self.minimum}, maximum={self.maximum}): {self._records}"

    def __bool__(self):

        return bool(self._records)

    def __len__(self):

        if self._is_length_even():
            return len(self._records)
        else:
            return len(self._records) - 1

    def __contains__(self,
                     record):

        if not self:
            return False
        elif self._is_heap_single_value():
            single_index = self._get_minimum_index(0)
            single_record = self._records[single_index]
            return record == single_record
        else:
            minimum_index = self._get_minimum_index(0)
            maximum_index = self._get_maximum_index(0)
            minimum_record = self._records[minimum_index]
            maximum_record = self._records[maximum_index]
            if not minimum_record <= record <= maximum_record:
                return False
            else:
                return record in self._records

    def __getitem__(self,
                    index):

        if not self:
            raise ValueError("an empty heap")
        elif not 0 <= index <= len(self._records) - 1:
            raise IndexError("an index out of range")
        else:
            return self._records[index]

    def __setitem__(self,
                    index,
                    record):

        raise AttributeError("an immutable attribute 'records'")

    def __delitem__(self,
                    index):

        if not self:
            raise ValueError("an empty heap")
        elif index == 0:
            self.extract_minimum()
        elif not self._is_heap_single_value() and index == 1:
            self.extract_maximum()
        else:
            raise AttributeError("an immutable attribute 'records'")

    @staticmethod
    def _get_minimum_index(node_index):

        return 2 * node_index

    @staticmethod
    def _get_maximum_index(node_index):

        return 2 * node_index + 1

    @staticmethod
    def _get_parent_node_index(node_index):

        if (node_index - 1) // 2 >= 0:
            return (node_index - 1) // 2
        else:
            return -1

    def _get_child_node_index(self,
                              node_index):

        if 2 * node_index + 2 <= len(self._records) // 2 - 1:
            return [2 * node_index + 1,
                    2 * node_index + 2]
        elif 2 * node_index + 1 <= len(self._records) // 2 - 1:
            return [2 * node_index + 1]
        else:
            return []

    def _is_length_even(self):

        if not self:
            return True
        elif self._terminal_record is None:
            return self._records[-1] is not None
        else:
            return self._records[-1] != self._terminal_record

    def _is_heap_single_value(self):

        if self._is_length_even():
            return False
        else:
            return len(self._records) == 2

    def _is_node_property_violated(self,
                                   node_index):

        left_index = self._get_minimum_index(node_index)
        right_index = self._get_maximum_index(node_index)
        left_key = self._extractor(self._records[left_index])
        right_key = self._extractor(self._records[right_index])

        if left_key is None or right_key is None:
            return False
        else:
            return left_key > right_key

    def _is_minimum_property_violated(self,
                                      left_node_index,
                                      right_node_index):

        left_index = self._get_minimum_index(left_node_index)
        right_index = self._get_minimum_index(right_node_index)
        left_key = self._extractor(self._records[left_index])
        right_key = self._extractor(self._records[right_index])

        if left_key is None or right_key is None:
            return False
        else:
            return left_key > right_key

    def _is_maximum_property_violated(self,
                                      left_node_index,
                                      right_node_index):

        left_index = self._get_maximum_index(left_node_index)
        right_index = self._get_maximum_index(right_node_index)
        left_key = self._extractor(self._records[left_index])
        right_key = self._extractor(self._records[right_index])

        if left_key is None or right_key is None:
            return False
        else:
            return left_key < right_key

    def _fix_node_property_violation(self,
                                     node_index):

        left_index = self._get_minimum_index(node_index)
        right_index = self._get_maximum_index(node_index)

        (self._records[left_index],
         self._records[right_index]) = (self._records[right_index],
                                        self._records[left_index])

    def _fix_minimum_property_violation(self,
                                        left_node_index,
                                        right_node_index):

        left_index = self._get_minimum_index(left_node_index)
        right_index = self._get_minimum_index(right_node_index)

        (self._records[left_index],
         self._records[right_index]) = (self._records[right_index],
                                        self._records[left_index])

    def _fix_maximum_property_violation(self,
                                        left_node_index,
                                        right_node_index):

        left_index = self._get_maximum_index(left_node_index)
        right_index = self._get_maximum_index(right_node_index)

        (self._records[left_index],
         self._records[right_index]) = (self._records[right_index],
                                        self._records[left_index])

    def _bubble_down_minimum(self,
                             node_index):

        are_minimums_swapped = True

        child_node_indices = self._get_child_node_index(node_index)
        if self._is_node_property_violated(node_index):
            self._fix_node_property_violation(node_index)

        while child_node_indices and are_minimums_swapped:

            target_node_index = child_node_indices[0]
            for current_node_index in child_node_indices[1:]:
                if self._is_minimum_property_violated(target_node_index, current_node_index):
                    target_node_index = current_node_index

            if self._is_minimum_property_violated(node_index, target_node_index):
                self._fix_minimum_property_violation(node_index,
                                                     target_node_index)
            else:
                are_minimums_swapped = False

            if are_minimums_swapped:

                node_index = target_node_index
                child_node_indices = self._get_child_node_index(node_index)

                if self._is_node_property_violated(node_index):
                    self._fix_node_property_violation(node_index)

    def _bubble_down_maximum(self,
                             node_index):

        are_maximums_swapped = True

        child_node_indices = self._get_child_node_index(node_index)
        if self._is_node_property_violated(node_index):
            self._fix_node_property_violation(node_index)

        while child_node_indices and are_maximums_swapped:

            target_node_index = child_node_indices[0]
            for current_node_index in child_node_indices[1:]:
                if self._is_maximum_property_violated(target_node_index, current_node_index):
                    target_node_index = current_node_index

            if self._is_maximum_property_violated(node_index, target_node_index):
                self._fix_maximum_property_violation(node_index,
                                                     target_node_index)
            else:
                are_maximums_swapped = False

            if are_maximums_swapped:

                node_index = target_node_index
                child_node_indices = self._get_child_node_index(node_index)

                if self._is_node_property_violated(node_index):
                    self._fix_node_property_violation(node_index)

    def _bubble_down(self,
                     node_index):

        self._bubble_down_minimum(node_index)
        self._bubble_down_maximum(node_index)

    def _bubble_up(self,
                   node_index):

        are_minimums_swapped = True
        are_maximums_swapped = True

        target_node_index = self._get_parent_node_index(node_index)
        if self._is_node_property_violated(node_index):
            self._fix_node_property_violation(node_index)

        while target_node_index >= 0 and (are_minimums_swapped or are_maximums_swapped):

            if self._is_minimum_property_violated(target_node_index, node_index):
                self._fix_minimum_property_violation(target_node_index,
                                                     node_index)
                are_minimums_swapped = True
            else:
                are_minimums_swapped = False

            if self._is_maximum_property_violated(target_node_index, node_index):
                self._fix_maximum_property_violation(target_node_index,
                                                     node_index)
                are_maximums_swapped = True
            else:
                are_maximums_swapped = False

            if are_minimums_swapped or are_maximums_swapped:

                node_index = target_node_index
                target_node_index = self._get_parent_node_index(node_index)
                if self._is_node_property_violated(node_index):
                    self._fix_node_property_violation(node_index)

    def insert(self,
               record):

        last_node_index = len(self._records) // 2
        parent_node_index = self._get_parent_node_index(last_node_index)
        if parent_node_index >= 0:
            minimum_index = self._get_minimum_index(parent_node_index)
            maximum_index = self._get_maximum_index(parent_node_index)
            minimum_record = self._records[minimum_index]
            maximum_record = self._records[maximum_index]
        else:
            minimum_record = None
            maximum_record = None

        if not self:
            self._records = [record, self._terminal_record]
        elif not self._is_length_even():
            self._records[-1] = record
            self._bubble_up(len(self._records) // 2 - 1)
        elif record < minimum_record:
            self._records.extend([record, self._terminal_record])
            self._bubble_up(len(self._records) // 2 - 1)
        elif record > maximum_record:
            self._records.extend([self._terminal_record, record])
            self._bubble_up(len(self._records) // 2 - 1)
            minimum_index = self._get_minimum_index(last_node_index)
            maximum_index = self._get_maximum_index(last_node_index)
            (self._records[minimum_index],
             self._records[maximum_index]) = (self._records[maximum_index],
                                              self._records[minimum_index])
        else:
            self._records.extend([record, self._terminal_record])

    def extract_minimum(self):

        if not self:
            raise ValueError("an empty heap")
        elif self._is_heap_single_value():
            minimum_record = self._records[0]
            self._records.pop(-1)
            self._records.pop(-1)
        elif self._is_length_even():
            last_index = self._get_maximum_index(len(self._records) // 2 - 1)
            minimum_index = self._get_minimum_index(0)
            minimum_record = self._records[minimum_index]
            self._records[minimum_index] = self._records[last_index]
            self._records[last_index] = self._terminal_record
            self._bubble_down_minimum(0)
        else:
            last_index = self._get_minimum_index(len(self._records) // 2 - 1)
            minimum_index = self._get_minimum_index(0)
            minimum_record = self._records[minimum_index]
            self._records[minimum_index] = self._records.pop(last_index)
            self._records.pop(-1)
            self._bubble_down_minimum(0)

        return minimum_record

    def extract_maximum(self):

        if not self:
            raise ValueError("an empty heap")
        elif self._is_heap_single_value():
            maximum_record = self._records[0]
            self._records.pop(-1)
            self._records.pop(-1)
        elif self._is_length_even():
            last_index = self._get_maximum_index(len(self._records) // 2 - 1)
            maximum_index = self._get_maximum_index(0)
            maximum_record = self._records[maximum_index]
            self._records[maximum_index] = self._records[last_index]
            self._records[last_index] = self._terminal_record
            self._bubble_down_maximum(0)
        else:
            last_index = self._get_minimum_index(len(self._records) // 2 - 1)
            maximum_index = self._get_maximum_index(0)
            maximum_record = self._records[maximum_index]
            self._records[maximum_index] = self._records.pop(last_index)
            self._records.pop(-1)
            self._bubble_down_maximum(0)

        return maximum_record

    @property
    def minimum(self):

        if not self:
            raise ValueError("an empty heap")
        else:
            minimum_index = self._get_minimum_index(0)
            return self._records[minimum_index]

    @property
    def maximum(self):

        if not self:
            raise ValueError("an empty heap")
        elif self._is_heap_single_value():
            maximum_index = self._get_minimum_index(0)
            return self._records[maximum_index]
        else:
            maximum_index = self._get_maximum_index(0)
            return self._records[maximum_index]

    @property
    def records(self):

        return self._records

    @records.setter
    def records(self,
                records):

        raise AttributeError("an immutable attribute 'records'")

    @property
    def extractor(self):

        return self._extractor

    @extractor.setter
    def extractor(self,
                  extractor):

        raise AttributeError("an immutable attribute 'extractor'")

    @property
    def terminal_record(self):

        return self._terminal_record

    @terminal_record.setter
    def terminal_record(self,
                        terminal_record):

        raise AttributeError("an immutable attribute 'terminal_record'")

    @property
    def mode(self):

        return "minimum-maximum"

    @mode.setter
    def mode(self,
             mode):

        raise AttributeError("an immutable attribute 'mode'")
