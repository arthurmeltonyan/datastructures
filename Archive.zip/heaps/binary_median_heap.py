import binary_heap as bh
from selection import single_quick_select as qs


class BinaryMedianHeap:

    def __init__(self,
                 values=None,
                 key=None,
                 special_value=None):

        if not callable(key):
            self._key = lambda value: value
        else:
            self._key = key

        self._mode = 'median'
        self._special_value = special_value

        if values is None:
            self._median = self._special_value
            self._max_heap = bh.BinaryHeap(mode='maximum',
                                           key=key)
            self._min_heap = bh.BinaryHeap(mode='minimum',
                                           key=key)
        else:
            selector = qs.QuickSelector()
            if len(values) % 2 == 0:
                left_median = selector.select(values, len(values) // 2)
                right_median = selector.select(values, len(values) // 2 + 1)
                self._median = self._special_value
            else:
                self._median = selector.select(values, len(values) // 2)
                left_median = self._median
                right_median = self._median

            smaller_values = [value
                              for value in values
                              if value < left_median]
            if len(smaller_values) < len(values) // 2:
                k = len(values) // 2 - len(smaller_values)
                smaller_values.extend([left_median] * k)
            self._max_heap = bh.BinaryHeap(smaller_values,
                                           mode='maximum',
                                           key=key)

            larger_values = [value
                             for value in values
                             if value > right_median]
            if len(larger_values) < len(values) // 2:
                k = len(values) // 2 - len(larger_values)
                larger_values.extend([right_median] * k)

            self._min_heap = bh.BinaryHeap(larger_values,
                                           mode='minimum',
                                           key=key)

    def __str__(self):

        if not self:
            return f"Binary Median Heap (): []"
        elif self._is_length_even():
            values = self._max_heap.values + self._min_heap.values
            return f"Binary Median Heap (left_median={self.left_median}, right_median={self.right_median}): {values}"
        else:
            values = [self._median] + self._max_heap.values + self._min_heap.values
            return f"Binary Median Heap (left_median={self.left_median}, right_median={self.right_median}): {values}"

    def __bool__(self):

        if self._special_value is None:
            return self._median is not None or bool(self._max_heap) or bool(self._min_heap)
        else:
            return self._median != self._special_value or bool(self._max_heap) or bool(self._min_heap)

    def __len__(self):

        if self._is_length_even():
            return len(self._max_heap) + len(self._min_heap)
        else:
            return 1 + len(self._max_heap) + len(self._min_heap)

    def __contains__(self,
                     value):

        if not self:
            return False
        elif self._is_length_even():
            return value in self._max_heap or value in self._min_heap
        else:
            return value == self._median or value in self._max_heap or value in self._min_heap

    def __getitem__(self,
                    node_index):

        if not self:
            raise IndexError("an empty heap")
        elif node_index == 0:
            return self._median
        elif self._is_index_max_heap(node_index):
            max_heap_node_index = self._get_max_heap_node_index(node_index)
            return self._max_heap[max_heap_node_index]
        elif self._is_index_min_heap(node_index):
            min_heap_node_index = self._get_min_heap_node_index(node_index)
            return self._min_heap[min_heap_node_index]
        else:
            raise IndexError("an index out of range")

    def __setitem__(self,
                    node_index,
                    value):

        if not self:
            self._median = value
        elif not self._is_length_even() and node_index == 0 and self._is_median_larger_than(value):
            self._max_heap.insert(value)
            self._min_heap.insert(self._median)
            self._median = self._special_value
        elif not self._is_length_even() and node_index == 0:
            self._min_heap.insert(value)
            self._max_heap.insert(self._median)
            self._median = self._special_value
        elif self._is_length_even() and node_index == 0 and self._is_left_median_larger_than(value):
            self._median = self._max_heap.extract()
            self._max_heap.insert(value)
        elif self._is_length_even() and node_index == 0 and self._is_right_median_smaller_than(value):
            self._median = self._min_heap.extract()
            self._min_heap.insert(value)
        elif self._is_length_even() and node_index == 0:
            self._median = value
        else:
            self.extract(node_index)
            self.insert(value)

    def __delitem__(self,
                    node_index):

        self.extract(node_index)

    def _is_length_even(self):

        if not self:
            return True
        elif self._special_value is None:
            return self._median is None
        else:
            return self._median == self._special_value

    def _is_index_max_heap(self,
                           node_index):

        return 0 <= node_index - 1 <= len(self._max_heap) - 1

    def _is_index_min_heap(self,
                           node_index):

        return 0 <= node_index - 1 - len(self._max_heap) <= len(self._min_heap) - 1

    def _get_max_heap_node_index(self,
                                 node_index):

        return node_index - 1

    def _get_min_heap_node_index(self,
                                 node_index):

        return node_index - 1 - len(self._min_heap)

    def _is_left_median_larger_than(self,
                                    value):

        key = self._key(value)
        left_median_key = self._key(self._max_heap.maximum)

        return key <= left_median_key

    def _is_right_median_smaller_than(self,
                                      value):

        key = self._key(value)
        right_median_key = self._key(self._min_heap.minimum)

        return key >= right_median_key

    def _is_median_larger_than(self,
                               value):

        key = self._key(value)
        median_key = self._key(self._median)

        return key < median_key

    def insert(self,
               value):

        if not self:
            self._median = value
        elif not self._is_length_even() and self._is_median_larger_than(value):
            self._max_heap.insert(value)
            self._min_heap.insert(self._median)
            self._median = self._special_value
        elif not self._is_length_even():
            self._min_heap.insert(value)
            self._max_heap.insert(self._median)
            self._median = self._special_value
        elif self._is_length_even() and self._is_left_median_larger_than(value):
            self._median = self._max_heap.extract()
            self._max_heap.insert(value)
        elif self._is_length_even() and self._is_right_median_smaller_than(value):
            self._median = self._min_heap.extract()
            self._min_heap.insert(value)
        else:
            self._median = value

    def extract(self,
                node_index=0):

        if not self:
            raise ValueError("an empty heap")
        elif not self._is_length_even() and node_index == 0:
            value = self._median
            self._median = self._special_value
            return value
        elif self._is_length_even() and node_index == 0:
            left_median = self._max_heap.extract()
            right_median = self._min_heap.extract()
            value = (left_median + right_median) / 2
            return value
        elif not self._is_length_even() and self._is_index_max_heap(node_index):
            max_heap_node_index = self._get_max_heap_node_index(node_index)
            value = self._max_heap.extract(max_heap_node_index)
            self._max_heap.insert(self._median)
            self._median = self._special_value
            return value
        elif self._is_length_even() and self._is_index_max_heap(node_index):
            max_heap_node_index = self._get_max_heap_node_index(node_index)
            value = self._max_heap.extract(max_heap_node_index)
            self._median = self._min_heap.extract()
            return value
        elif not self._is_length_even() and self._is_index_min_heap(node_index):
            min_heap_node_index = self._get_min_heap_node_index(node_index)
            value = self._min_heap.extract(min_heap_node_index)
            self._min_heap.insert(self._median)
            self._median = self._special_value
            return value
        elif self._is_length_even() and self._is_index_min_heap(node_index):
            min_heap_node_index = self._get_min_heap_node_index(node_index)
            value = self._min_heap.extract(min_heap_node_index)
            self._median = self._max_heap.extract()
            return value
        else:
            raise IndexError("an index out of range")

    @property
    def median(self):

        if not self:
            raise IndexError("an empty heap")
        elif self._is_length_even():
            return (self._max_heap.maximum + self._min_heap.minimum) / 2
        else:
            return self._median

    @property
    def left_median(self):

        if not self:
            raise IndexError("an empty heap")
        elif self._is_length_even():
            return self._max_heap.maximum
        else:
            return self._median

    @property
    def right_median(self):

        if not self:
            raise IndexError("an empty heap")
        elif self._is_length_even():
            return self._min_heap.minimum
        else:
            return self._median

    @property
    def values_below_median(self):

        return self._max_heap.values

    @values_below_median.setter
    def values_below_median(self,
                            values_below_median):

        raise AttributeError("an immutable attribute 'values_below_median'")

    @property
    def values_above_median(self):

        return self._min_heap.values

    @values_above_median.setter
    def values_above_median(self,
                            values_above_median):

        raise AttributeError("an immutable attribute 'values_above_median'")

    @property
    def key(self):

        return self._key

    @key.setter
    def key(self,
            key):

        raise AttributeError("an immutable attribute 'key'")

    @property
    def mode(self):

        return self._mode

    @mode.setter
    def mode(self,
             mode):

        raise AttributeError("an immutable attribute 'mode'")
