import pytest
import random

import binary_heap
import binary_min_max_pair_heap


@pytest.fixture
def many_unsorted_records():

    return [random.randint(-1000000, 1000000)
            for _ in range(100000)]


@pytest.fixture
def minimums():

    return [random.randint(-10000000, -1000000)
            for _ in range(10000)]


@pytest.fixture
def maximums():

    return [random.randint(1000000, 10000000)
            for _ in range(10000)]


@pytest.fixture
def many_naturally_sorted_records(many_unsorted_records):

    return sorted(many_unsorted_records,
                  reverse=False)


@pytest.fixture
def many_reversely_sorted_records(many_naturally_sorted_records):

    return many_naturally_sorted_records[::-1]


@pytest.fixture
def many_naturally_sorted_minimums(minimums):

    return sorted(minimums,
                  reverse=False)


@pytest.fixture
def many_reversely_sorted_maximums(maximums):

    return sorted(maximums,
                  reverse=True)


class TestBinaryMinHeap:

    @staticmethod
    def test_heap_creation(many_unsorted_records):
        
        heap = binary_heap.BinaryHeap(many_unsorted_records,
                                      is_order_natural=True)

        assert len(heap) == len(many_unsorted_records)

    @staticmethod
    def test_natural(many_unsorted_records,
                     many_naturally_sorted_records):
    
        heap = binary_heap.BinaryHeap(many_unsorted_records,
                                      is_order_natural=True)
        sorted_records = [heap.extract()
                          for _ in range(len(heap))]
    
        assert not heap and sorted_records == many_naturally_sorted_records

    @staticmethod
    def test_updated_natural(many_unsorted_records,
                             minimums,
                             maximums,
                             many_naturally_sorted_minimums):
    
        heap = binary_heap.BinaryHeap(many_unsorted_records,
                                      is_order_natural=True)
        for value in random.sample(minimums + maximums,
                                   k=len(minimums) + len(maximums)):
            heap.insert(value)
        sorted_minimums = [heap.extract()
                           for _ in range(len(minimums))]
    
        assert heap and sorted_minimums == many_naturally_sorted_minimums


class TestBinaryMaxHeap:

    @staticmethod
    def test_heap_creation(many_unsorted_records):
        heap = binary_heap.BinaryHeap(many_unsorted_records,
                                      is_order_natural=False)

        assert len(heap) == len(many_unsorted_records)

    @staticmethod
    def test_reverse(many_unsorted_records,
                     many_reversely_sorted_records):
    
        heap = binary_heap.BinaryHeap(many_unsorted_records,
                                      is_order_natural=False)
        sorted_records = [heap.extract()
                          for _ in range(len(heap))]
    
        assert not heap and sorted_records == many_reversely_sorted_records

    @staticmethod
    def test_updated_reverse(many_unsorted_records,
                             minimums,
                             maximums,
                             many_reversely_sorted_maximums):
    
        heap = binary_heap.BinaryHeap(many_unsorted_records,
                                      is_order_natural=False)
        for value in random.sample(minimums + maximums,
                                   k=len(minimums) + len(maximums)):
            heap.insert(value)
        sorted_maximums = [heap.extract()
                           for _ in range(len(maximums))]
    
        assert heap and sorted_maximums == many_reversely_sorted_maximums


class TestBinaryMinMaxPairHeap:

    @staticmethod
    def test_heap_creation(many_unsorted_records):

        heap = binary_min_max_pair_heap.BinaryMinMaxPairHeap(many_unsorted_records)

        assert len(heap) == len(many_unsorted_records)

    @staticmethod
    def test_natural(many_unsorted_records,
                     many_naturally_sorted_records):

        heap = binary_min_max_pair_heap.BinaryMinMaxPairHeap(many_unsorted_records)
        sorted_records = [heap.extract_minimum()
                          for _ in range(len(heap))]

        assert not heap and sorted_records == many_naturally_sorted_records

    @staticmethod
    def test_updated_natural(many_unsorted_records,
                             minimums,
                             maximums,
                             many_naturally_sorted_minimums):

        heap = binary_min_max_pair_heap.BinaryMinMaxPairHeap(many_unsorted_records)
        for value in random.sample(minimums + maximums,
                                   k=len(minimums) + len(maximums)):
            heap.insert(value)
        sorted_minimums = [heap.extract_minimum()
                           for _ in range(len(minimums))]

        assert heap and sorted_minimums == many_naturally_sorted_minimums

    @staticmethod
    def test_reverse(many_unsorted_records,
                     many_reversely_sorted_records):

        heap = binary_min_max_pair_heap.BinaryMinMaxPairHeap(many_unsorted_records)
        sorted_records = [heap.extract_maximum()
                          for _ in range(len(heap))]

        assert not heap and sorted_records == many_reversely_sorted_records

    @staticmethod
    def test_updated_reverse(many_unsorted_records,
                             minimums,
                             maximums,
                             many_reversely_sorted_maximums):

        heap = binary_min_max_pair_heap.BinaryMinMaxPairHeap(many_unsorted_records)
        for value in random.sample(minimums + maximums,
                                   k=len(minimums) + len(maximums)):
            heap.insert(value)
        sorted_maximums = [heap.extract_maximum()
                           for _ in range(len(maximums))]

        assert heap and sorted_maximums == many_reversely_sorted_maximums
