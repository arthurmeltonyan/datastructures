class BinaryHeap:

    def __init__(self,
                 records=None,
                 extractor=None,
                 is_order_natural=True):

        if not callable(extractor):
            self._extractor = lambda record: record
        else:
            self._extractor = extractor

        if is_order_natural:
            self._is_order_natural = True
        else:
            self._is_order_natural = False

        if records is None:
            self._records = []
        else:
            self._records = list(records)
            for node_index in range((len(self._records) - 1) // 2, -1, -1):
                self._bubble_down(node_index)

    def __str__(self):

        if not self and self._is_order_natural:
            return f"Binary Min Heap (): []"
        elif not self:
            return f"Binary Max Heap (): []"
        elif self._is_order_natural:
            return f"Binary Min Heap (minimum={self.minimum}): {self._records}"
        else:
            return f"Binary Max Heap (maximum={self.maximum}): {self._records}"

    def __bool__(self):

        return bool(self._records)

    def __len__(self):

        return len(self._records)

    def __contains__(self,
                     record):

        if not self:
            return False
        elif record < self._records[0] and self._is_order_natural:
            return False
        elif record < self._records[0]:
            return record in self._records
        elif self._is_order_natural:
            return record in self._records
        else:
            return False

    def __getitem__(self,
                    node_index):

        if not self:
            raise ValueError("an empty heap")
        elif not 0 <= node_index <= len(self._records) - 1:
            raise IndexError("an index out of range")
        else:
            return self._records[node_index]

    def __setitem__(self,
                    node_index,
                    record):

        if not self:
            raise ValueError("an empty heap")
        elif not 0 <= node_index <= len(self._records) - 1:
            raise IndexError("an index out of range")
        elif self._is_order_natural:
            old_record, self._records[node_index] = self._records[node_index], record
            old_key = self._extractor(old_record)
            new_key = self._extractor(record)

            if new_key < old_key:
                self._bubble_up(node_index)
            else:
                self._bubble_down(node_index)
        else:
            old_record, self._records[node_index] = self._records[node_index], record
            old_key = self._extractor(old_record)
            new_key = self._extractor(record)

            if new_key > old_key:
                self._bubble_up(node_index)
            else:
                self._bubble_down(node_index)

    def __delitem__(self,
                    node_index):

        self.extract(node_index)

    @staticmethod
    def _get_parent_node_index(node_index):

        if (node_index - 1) // 2 >= 0:
            return (node_index - 1) // 2
        else:
            return -1

    def _get_child_node_index(self,
                              node_index):

        if 2 * node_index + 2 <= len(self._records) - 1:
            return [2 * node_index + 1,
                    2 * node_index + 2]
        elif 2 * node_index + 1 <= len(self._records) - 1:
            return [2 * node_index + 1]
        else:
            return []

    def _is_minimum_property_violated(self,
                                      left_node_index,
                                      right_node_index):

        if left_node_index < 0 or right_node_index < 0:
            return False
        else:
            left_key = self._extractor(self._records[left_node_index])
            right_key = self._extractor(self._records[right_node_index])
            return left_key > right_key

    def _is_maximum_property_violated(self,
                                      left_node_index,
                                      right_node_index):

        if left_node_index < 0 or right_node_index < 0:
            return False
        else:
            left_key = self._extractor(self._records[left_node_index])
            right_key = self._extractor(self._records[right_node_index])
            return left_key < right_key

    def _fix_property_violation(self,
                                left_node_index,
                                right_node_index):

        (self._records[left_node_index],
         self._records[right_node_index]) = (self._records[right_node_index],
                                             self._records[left_node_index])

    def _fix_minimum_property_violation(self,
                                        left_node_index,
                                        right_node_index):

        self._fix_property_violation(left_node_index,
                                     right_node_index)

    def _fix_maximum_property_violation(self,
                                        left_node_index,
                                        right_node_index):

        self._fix_property_violation(left_node_index,
                                     right_node_index)

    def _bubble_down_minimum(self,
                             node_index):

        are_minimums_swapped = True

        child_node_indices = self._get_child_node_index(node_index)

        while child_node_indices and are_minimums_swapped:

            target_node_index = child_node_indices[0]
            for current_node_index in child_node_indices[1:]:
                if self._is_minimum_property_violated(target_node_index, current_node_index):
                    target_node_index = current_node_index

            if self._is_minimum_property_violated(node_index, target_node_index):
                self._fix_minimum_property_violation(node_index,
                                                     target_node_index)
            else:
                are_minimums_swapped = False

            if are_minimums_swapped:

                node_index = target_node_index
                child_node_indices = self._get_child_node_index(node_index)

    def _bubble_down_maximum(self,
                             node_index):

        are_maximums_swapped = True

        child_node_indices = self._get_child_node_index(node_index)

        while child_node_indices and are_maximums_swapped:

            target_node_index = child_node_indices[0]
            for current_node_index in child_node_indices[1:]:
                if self._is_maximum_property_violated(target_node_index, current_node_index):
                    target_node_index = current_node_index

            if self._is_maximum_property_violated(node_index, target_node_index):
                self._fix_maximum_property_violation(node_index,
                                                     target_node_index)
            else:
                are_maximums_swapped = False

            if are_maximums_swapped:

                node_index = target_node_index
                child_node_indices = self._get_child_node_index(node_index)

    def _bubble_down(self,
                     node_index):

        if self._is_order_natural:
            self._bubble_down_minimum(node_index)
        else:
            self._bubble_down_maximum(node_index)

    def _bubble_up_minimum(self,
                           node_index):

        are_minimums_swapped = True

        target_node_index = self._get_parent_node_index(node_index)

        while target_node_index >= 0 and are_minimums_swapped:

            if self._is_minimum_property_violated(target_node_index, node_index):
                self._fix_minimum_property_violation(target_node_index,
                                                     node_index)
            else:
                are_minimums_swapped = False

            if are_minimums_swapped:

                node_index = target_node_index
                target_node_index = self._get_parent_node_index(node_index)

    def _bubble_up_maximum(self,
                           node_index):

        are_maximums_swapped = True

        target_node_index = self._get_parent_node_index(node_index)

        while target_node_index >= 0 and are_maximums_swapped:

            if self._is_maximum_property_violated(target_node_index, node_index):
                self._fix_maximum_property_violation(target_node_index,
                                                     node_index)
            else:
                are_maximums_swapped = False

            if are_maximums_swapped:

                node_index = target_node_index
                target_node_index = self._get_parent_node_index(node_index)

    def _bubble_up(self,
                   node_index):

        if self._is_order_natural:
            self._bubble_up_minimum(node_index)
        else:
            self._bubble_up_maximum(node_index)

    def insert(self,
               record):

        self._records.append(record)
        self._bubble_up(len(self._records) - 1)

    def extract(self,
                node_index=0):

        if not self:
            raise ValueError("an empty heap")
        elif not 0 <= node_index <= len(self._records) - 1:
            raise IndexError("an index out of range")
        else:
            self._records[node_index], self._records[-1] = self._records[-1], self._records[node_index]
            record = self._records.pop()
            self._bubble_down(node_index)
            return record

    @property
    def minimum(self):

        if not self:
            raise ValueError("an empty heap")
        elif self._is_order_natural:
            return self._records[0]
        else:
            raise ValueError("an unavailable property 'minimum'")

    @property
    def maximum(self):

        if not self:
            raise ValueError("an empty heap")
        elif not self._is_order_natural:
            return self._records[0]
        else:
            raise ValueError("an unavailable property 'maximum'")

    @property
    def records(self):

        return self._records

    @records.setter
    def records(self,
                records):

        raise AttributeError("an immutable attribute 'records'")

    @property
    def extractor(self):

        return self._extractor

    @extractor.setter
    def extractor(self,
                  extractor):

        raise AttributeError("an immutable attribute 'extractor'")

    @property
    def is_order_natural(self):

        return self._is_order_natural

    @is_order_natural.setter
    def is_order_natural(self,
                         is_order_natural):

        raise AttributeError("an immutable attribute 'is_order_natural'")

    @property
    def mode(self):

        if self._is_order_natural:
            return 'minimum'
        else:
            return 'maximum'

    @mode.setter
    def mode(self,
             mode):

        raise AttributeError("an immutable attribute 'mode'")
