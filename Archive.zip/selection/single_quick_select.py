class RecursiveSingleQuickSelector:

    def __init__(self):

        self._record_extractor = None

    def _partition_two(self,
                       records,
                       index):

        a, b = records[index: index + 2]
        if self._record_extractor(a) > self._record_extractor(b):
            records[index: index + 2] = [b, a]
        else:
            records[index: index + 2] = [a, b]

        return index + 1

    def _partition_three(self,
                         records,
                         index):

        a, b, c = records[index: index + 3]
        if self._record_extractor(a) > self._record_extractor(b):
            a, b = b, a
        if self._record_extractor(b) > self._record_extractor(c):
            b, c = c, b
        if self._record_extractor(a) > self._record_extractor(b):
            a, b = b, a
        records[index: index + 3] = [a, b, c]

        return index + 1

    def _partition_four(self,
                        records,
                        index):

        a, b, c, d = records[index: index + 4]
        if self._record_extractor(a) > self._record_extractor(b):
            a, b = b, a
        if self._record_extractor(c) > self._record_extractor(d):
            c, d = d, c
        if self._record_extractor(a) > self._record_extractor(c):
            a, c = c, a
            b, d = d, b

        if self._record_extractor(b) > self._record_extractor(d):
            records[index: index + 4] = [a, c, d, b]
        elif self._record_extractor(b) > self._record_extractor(c):
            records[index: index + 4] = [a, c, b, d]
        else:
            records[index: index + 4] = [a, b, c, d]

        return index + 2

    def _partition_five(self,
                        records,
                        index):

        a, b, c, d, e = records[index: index + 5]
        if self._record_extractor(a) > self._record_extractor(b):
            a, b = b, a
        if self._record_extractor(c) > self._record_extractor(d):
            c, d = d, c
        if self._record_extractor(a) > self._record_extractor(c):
            a, c = c, a
            b, d = d, b

        if self._record_extractor(e) > self._record_extractor(c):
            if self._record_extractor(e) > self._record_extractor(d):
                if self._record_extractor(b) > self._record_extractor(d):
                    if self._record_extractor(b) > self._record_extractor(e):
                        records[index: index + 5] = [a, c, d, e, b]
                    else:
                        records[index: index + 5] = [a, c, d, b, e]
                else:
                    if self._record_extractor(b) < self._record_extractor(c):
                        records[index: index + 5] = [a, b, c, d, e]
                    else:
                        records[index: index + 5] = [a, c, b, d, e]
            else:
                if self._record_extractor(b) > self._record_extractor(e):
                    if self._record_extractor(b) > self._record_extractor(d):
                        records[index: index + 5] = [a, c, e, d, b]
                    else:
                        records[index: index + 5] = [a, c, e, b, d]
                else:
                    if self._record_extractor(b) < self._record_extractor(c):
                        records[index: index + 5] = [a, b, c, e, d]
                    else:
                        records[index: index + 5] = [a, c, b, e, d]
        else:
            if self._record_extractor(e) < self._record_extractor(a):
                if self._record_extractor(b) > self._record_extractor(c):
                    if self._record_extractor(b) > self._record_extractor(d):
                        records[index: index + 5] = [e, a, c, d, b]
                    else:
                        records[index: index + 5] = [e, a, c, b, d]
                else:
                    records[index: index + 5] = [e, a, b, c, d]
            else:
                if self._record_extractor(b) > self._record_extractor(c):
                    if self._record_extractor(b) > self._record_extractor(d):
                        records[index: index + 5] = [a, e, c, d, b]
                    else:
                        records[index: index + 5] = [a, e, c, b, d]
                else:
                    if self._record_extractor(b) < self._record_extractor(e):
                        records[index: index + 5] = [a, b, e, c, d]
                    else:
                        records[index: index + 5] = [a, e, b, c, d]

        return index + 2

    def _pivot(self,
               records,
               initial_index,
               terminal_index):

        length = terminal_index - initial_index + 1
        if length == 1:
            return initial_index
        elif length == 2:
            return self._partition_two(records,
                                       initial_index)
        elif length == 3:
            return self._partition_three(records,
                                         initial_index)
        elif length == 4:
            return self._partition_four(records,
                                        initial_index)

        chunk_count = length // 5
        for index in range(chunk_count):
            median_index = self._partition_five(records,
                                                initial_index + index * 5)
            new_index = initial_index + index
            records[new_index], records[median_index] = records[median_index], records[new_index]

        last_chunk_size = length % 5
        if last_chunk_size == 4:
            median_index = self._partition_four(records,
                                                initial_index + chunk_count * 5)
            new_index = initial_index + chunk_count
            records[new_index], records[median_index] = records[median_index], records[new_index]
            chunk_count += 1
        elif last_chunk_size == 3:
            median_index = self._partition_three(records,
                                                 initial_index + chunk_count * 5)
            new_index = initial_index + chunk_count
            records[new_index], records[median_index] = records[median_index], records[new_index]
            chunk_count += 1
        elif last_chunk_size == 2:
            median_index = self._partition_two(records,
                                               initial_index + chunk_count * 5)
            new_index = initial_index + chunk_count
            records[new_index], records[median_index] = records[median_index], records[new_index]
            chunk_count += 1
        elif last_chunk_size == 1:
            median_index = initial_index + chunk_count * 5
            new_index = initial_index + chunk_count
            records[new_index], records[median_index] = records[median_index], records[new_index]
            chunk_count += 1

        return self._select(records,
                            initial_index,
                            initial_index + chunk_count - 1,
                            initial_index + (chunk_count - 1) // 2)

    def _partition(self,
                   records,
                   initial_index,
                   terminal_index,
                   pivot_index):

        pivot_key = self._record_extractor(records[pivot_index])
        records[pivot_index], records[initial_index] = records[initial_index], records[pivot_index]

        begin_index = initial_index + 1
        end_index = terminal_index
        did_indices_cross = False

        while not did_indices_cross:

            while begin_index <= terminal_index and pivot_key > self._record_extractor(records[begin_index]):
                begin_index += 1

            while end_index > initial_index and pivot_key < self._record_extractor(records[end_index]):
                end_index -= 1

            if begin_index <= end_index:
                records[begin_index], records[end_index] = records[end_index], records[begin_index]
                begin_index += 1
                end_index -= 1
            else:
                did_indices_cross = True

        records[end_index], records[initial_index] = records[initial_index], records[end_index]

        return end_index

    def _select(self,
                records,
                initial_index,
                terminal_index,
                order):

        if initial_index == terminal_index:
            return initial_index

        pivot_index = self._pivot(records,
                                  initial_index,
                                  terminal_index)
        partition_index = self._partition(records,
                                          initial_index,
                                          terminal_index,
                                          pivot_index)

        if order < partition_index:
            index = self._select(records,
                                 initial_index,
                                 partition_index - 1,
                                 order)
        elif order > partition_index:
            index = self._select(records,
                                 partition_index + 1,
                                 terminal_index,
                                 order)
        else:
            index = partition_index

        return index

    def select(self,
               records,
               order,
               extractor=None,
               is_order_natural=True):

        if not records:
            raise ValueError("an empty array")
        elif not 1 <= order <= len(records):
            raise ValueError("'order' is out of range")

        if not callable(extractor) and is_order_natural:
            self._record_extractor = lambda record: record
        elif not callable(extractor):
            self._record_extractor = lambda record: -record
        elif is_order_natural:
            self._record_extractor = lambda record: extractor(record)
        else:
            self._record_extractor = lambda record: -extractor(record)

        return self._select(records,
                            0,
                            len(records) - 1,
                            order - 1)


def recursive_get_single_smallest(records,
                                  order,
                                  extractor=None):

    selector = RecursiveSingleQuickSelector()
    index = selector.select(records,
                            order,
                            extractor=extractor,
                            is_order_natural=True)

    return records[index]


def recursive_get_single_largest(records,
                                 order,
                                 extractor=None):

    selector = RecursiveSingleQuickSelector()
    index = selector.select(records,
                            order,
                            extractor=extractor,
                            is_order_natural=False)

    return records[index]
