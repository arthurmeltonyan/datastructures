import pytest
import random

import single_quick_select
import multiple_quick_select


@pytest.fixture
def unsorted_records():

    return [random.randint(-1000000, 1000000)
            for _ in range(1000000)]


@pytest.fixture
def order():

    return random.randint(1, 1000001)


@pytest.fixture
def order_count(order):

    return 100


@pytest.fixture
def orders(order_count):

    return [random.randint(1, 1000001)
            for _ in range(order_count)]


@pytest.fixture
def sorted_records(unsorted_records):

    return sorted(unsorted_records,
                  reverse=False)


@pytest.fixture
def single_smallest(sorted_records,
                    order):

    return sorted_records[order - 1]


@pytest.fixture
def single_largest(sorted_records,
                   order):

    return sorted_records[-order]


@pytest.fixture
def multiple_smallest(sorted_records,
                      orders):

    return [sorted_records[order - 1]
            for order in sorted(orders)]


@pytest.fixture
def multiple_largest(sorted_records,
                     orders):

    return [sorted_records[-order]
            for order in sorted(orders)]


class TestRecursiveSingleQuickSelector:

    @staticmethod
    def test_smallest(unsorted_records,
                      order,
                      single_smallest):

        smallest = single_quick_select.recursive_get_single_smallest(unsorted_records,
                                                                     order=order)
        assert smallest == single_smallest

    @staticmethod
    def test_largest(unsorted_records,
                     order,
                     single_largest):

        largest = single_quick_select.recursive_get_single_largest(unsorted_records,
                                                                   order=order)
        assert largest == single_largest


class TestRecursiveMultipleQuickSelector:

    @staticmethod
    def test_smallest(unsorted_records,
                      orders,
                      multiple_smallest):

        smallest = multiple_quick_select.recursive_get_multiple_smallest(unsorted_records,
                                                                         orders=orders)
        assert smallest == multiple_smallest

    @staticmethod
    def test_largest(unsorted_records,
                     orders,
                     multiple_largest):

        largest = multiple_quick_select.recursive_get_multiple_largest(unsorted_records,
                                                                       orders=orders)
        assert largest == multiple_largest
