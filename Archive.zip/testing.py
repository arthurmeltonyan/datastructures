import random
import math
import time


def binary_search(records,
                  target):

    if not records:
        return -1
    elif target < records[0]:
        return -1
    elif target > records[-1]:
        return -1

    low = 0
    high = len(records) - 1

    while low < high:

        middle = low + (high - low) // 2
        if target > records[middle]:
            low = middle + 1
        else:
            high = middle

    if target == records[low]:
        return low
    else:
        return -1


def adaptive_search(records,
                    target):

    if not records:
        return -1
    elif target < records[0]:
        return -1
    elif target > records[-1]:
        return -1

    low = 0
    high = len(records) - 1

    while low < high and records[low] < records[high]:

        interpolation = low + int((high - low) * (target - records[low]) // (records[high] - records[low]))

        half_interval = (high - low) // 2
        if target < records[interpolation] and (interpolation - low) > half_interval:
            high = interpolation - 1
            interpolation = low + (high - low) // 2
        elif target > records[interpolation] and (high - interpolation) > half_interval:
            low = interpolation + 1
            interpolation = low + (high - low) // 2

        if target < records[interpolation]:
            high = interpolation - 1
        elif target > records[interpolation]:
            low = interpolation + 1
        else:
            return interpolation

    if target == records[low]:
        return low
    elif target == records[high]:
        return high
    else:
        return -1


def interpolated_binary_search(records,
                               target):

    if not records:
        return -1
    elif target < records[0]:
        return -1
    elif target > records[-1]:
        return -1

    low = 0
    high = len(records) - 1

    while low < high and records[low] < records[high]:

        interpolation = low + int((high - low) * (target - records[low]) // (records[high] - records[low]))

        if target > records[interpolation]:
            middle = high - (high - interpolation) // 2
            if target <= records[middle]:
                low = interpolation + 1
                high = middle
            else:
                low = middle + 1
        elif target < records[interpolation]:
            middle = low + (interpolation - low) // 2
            if target >= records[middle]:
                low = middle
                high = interpolation - 1
            else:
                high = middle - 1
        else:
            return interpolation

    if target == records[low]:
        return low
    else:
        return -1


def flexable_search(records,
                    target):

    if not records:
        return -1
    elif target < records[0]:
        return -1
    elif target > records[-1]:
        return -1

    low = 0
    high = len(records) - 1

    while low < high and records[low] < records[high]:

        interpolation = low + int((high - low) * (target - records[low]) // (records[high] - records[low]))

        if target < records[interpolation]:
            high = interpolation - 1
        elif target > records[interpolation]:
            low = interpolation + 1
        else:
            return interpolation

        middle = low + (high - low) // 2
        if records[middle] < target:
            low = middle + 1
        else:
            high = middle

    if target == records[low]:
        return low
    else:
        return -1


def generate_distributions(size):
    distributions = {}

    distributions["Uniform"] = sorted(random.sample(range(size * 3), size))
    distributions["Linear"] = sorted(range(0, size * 2, 2))
    print(distributions.keys())
    exponential = []
    current = 1
    for _ in range(size):
        current += int(random.random() * 10) + 1
        exponential.append(current)
    distributions["Exponential"] = exponential
    print(distributions.keys())
    clustered = []
    for i in range(0, size, 100):
        base = i * 10
        clustered.extend(base + random.randint(0, 50) for _ in range(100))
    distributions["Clustered"] = sorted(clustered)
    print(distributions.keys())
    step = []
    current = 0
    for _ in range(size):
        if random.random() < 0.1:
            current += random.randint(100, 200)
        step.append(current)
    distributions["Step"] = sorted(step)
    print(distributions.keys())
    bimodal = []
    for _ in range(size):
        if random.random() < 0.5:
            bimodal.append(random.gauss(size // 4, size // 10))
        else:
            bimodal.append(random.gauss(3 * size // 4, size // 10))
    distributions["Bimodal"] = sorted(map(int, bimodal))
    print(distributions.keys())
    periodic = []
    for i in range(size):
        base = i * 2
        variation = random.randint(-10, 10)
        periodic.append(base + 50 * math.sin(i / 50) + variation)
    distributions["Periodic"] = sorted(map(int, periodic))
    print(distributions.keys())
    power_law = []
    for _ in range(size):
        value = random.paretovariate(1.5)
        power_law.append(int(value * 100))
    distributions["PowerLaw"] = sorted(power_law)
    print(distributions.keys())
    sparse = [0] * size
    num_nonzero = size // 10
    positions = random.sample(range(size), num_nonzero)
    for pos in positions:
        sparse[pos] = random.randint(1, 1000)
    distributions["Sparse"] = sorted(sparse)
    print(distributions.keys())
    zipfian = []
    for i in range(1, size + 1):
        value = int((1 / i) * size * 10)
        zipfian.append(value + random.randint(-value // 10, value // 10))
    distributions["Zipfian"] = sorted(zipfian)
    print(distributions.keys())
    lognormal = []
    for _ in range(size):
        value = math.exp(random.gauss(0, 1))
        lognormal.append(int(value * 100))
    distributions["LogNormal"] = sorted(lognormal)
    print(distributions.keys())
    multimodal = []
    modes = [size // 5, 2 * size // 5, 3 * size // 5, 4 * size // 5]
    for _ in range(size):
        mode = random.choice(modes)
        multimodal.append(random.gauss(mode, size // 20))
    distributions["Multimodal"] = sorted(map(int, multimodal))
    print(distributions.keys())
    sawtooth = []
    period = size // 10
    for i in range(size):
        base = (i % period) * (1000 // period)
        variation = random.randint(-20, 20)
        sawtooth.append(base + variation)
    distributions["Sawtooth"] = sorted(sawtooth)
    print(distributions.keys())
    return distributions


def print_table(results,
                headers):

    widths = [max(len(str(row[index])) for row in results + [headers])
              for index in range(len(headers))]
    separator = "+" + "+".join("-" * (width + 2)
                               for width in widths) + "+"

    print(separator)
    print("| " + " | ".join(f"{str(value):<{width}}"
                            for value, width in zip(headers, widths)) + " |")
    print(separator)
    for row in results:
        print("| " + " | ".join(f"{str(value):<{width}}"
                                for value, width in zip(row, widths)) + " |")
    print(separator)


def main():

    n = 10000000
    k = 10000

    distributions = generate_distributions(n)
    algorithms = {"Binary Search": binary_search,
                  "Adaptive Search": adaptive_search,
                  "Interpolated Binary Search": interpolated_binary_search,
                  "Flexible Search": flexable_search}

    headers = ["Algorithm"] + list(distributions.keys())
    results = []

    for name, function in algorithms.items():
        print(name)
        row = [name]
        for records in distributions.values():
            targets = random.sample(records, k)
            begin_time = time.time()
            for target in targets:
                function(records, target)
            end_time = time.time()
            time_taken = end_time - begin_time
            row.append(f"{time_taken * 1000:.2f}ms")
        results.append(row)

    print_table(results, headers)


if __name__ == "__main__":
    main()
