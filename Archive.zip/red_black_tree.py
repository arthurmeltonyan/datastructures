import numpy as np
import matplotlib.pyplot as plt


class PlainSGDLinearRegression:

    def __init__(self):

        self._weight = None
        self._bias = None
        self._losses = []

    def fit(self,
            X,
            y,
            learning_rate=0.01):

        n_samples, n_features = X.shape
        self._weight = np.zeros(n_features)
        self._bias = 0.0

        for index in range(n_samples):

            y_predicted = self.predict(X[index])
            error = y_predicted - y[index]

            weight_gradient = 2 * error * X[index]
            bias_gradient = 2 * error

            self._weight -= learning_rate * weight_gradient.flatten()
            self._bias -= learning_rate * bias_gradient

            loss = np.mean((y - self.predict(X)) ** 2)
            self._losses.append(loss)

    def predict(self,
                X):

        return X.dot(self._weight) + self._bias

    @property
    def bias(self):

        return self._bias

    @property
    def weight(self):

        return self._weight

    @property
    def losses(self):

        return self._losses



def main():
    np.random.seed(42)

    # Data generation
    n_samples = 1000
    n_features = 3
    X = np.random.randn(n_samples, n_features)
    true_weight = np.random.randn(n_features)
    true_bias = 5.0
    noise = np.random.randn(n_samples) * 0.5
    y = X.dot(true_weight) + true_bias + noise

    # Train-test split
    train_ratio = 0.8
    train_size = int(n_samples * train_ratio)
    X_train = X[:train_size]
    y_train = y[:train_size]
    X_test = X[train_size:]
    y_test = y[train_size:]

    # Train Plain SGD model
    plain_model = PlainSGDLinearRegression()
    plain_model.fit(X_train, y_train, learning_rate=0.1)

    # Train Kalman SGD model
    kalman_model = PlainSGDLinearRegression()
    kalman_model.fit(X_train, y_train, learning_rate=0.1)

    # Test both models
    plain_y_predicted = plain_model.predict(X_test)
    plain_test_loss = np.mean((y_test - plain_y_predicted) ** 2)

    kalman_y_predicted = kalman_model.predict(X_test)
    kalman_test_loss = np.mean((y_test - kalman_y_predicted) ** 2)

    print(f'Plain SGD Test Loss: {plain_test_loss:.4f}')
    print(f'Kalman SGD Test Loss: {kalman_test_loss:.4f}')
    print(f'True Bias: {true_bias:.4f}')
    print(f'Plain SGD Learned Bias: {plain_model.bias:.4f}')
    print(f'Kalman SGD Learned Bias: {kalman_model.bias:.4f}')

    # Plot losses
    plt.figure(figsize=(20, 10))
    plt.plot(range(1, len(plain_model.losses) + 1), plain_model.losses, label='Plain SGD', color='blue')
    plt.plot(range(1, len(kalman_model.losses) + 1), kalman_model.losses, label='Kalman SGD', color='red')
    plt.xlabel('Iteration')
    plt.ylabel('Mean Squared Error Loss')
    plt.title('Training Loss per Iteration')
    plt.legend()
    plt.grid(True)
    plt.show()

    # Plot weights
    plt.figure(figsize=(20, 10))
    width = 0.2
    indices = np.arange(len(true_weight))
    plt.bar(indices - width, true_weight, width=width, label='True Weights', color='green')
    plt.bar(indices, plain_model.weight, width=width, label='Plain SGD Weights', color='blue')
    plt.bar(indices + width, kalman_model.weight, width=width, label='Kalman SGD Weights', color='red')
    plt.xlabel('Feature Index')
    plt.ylabel('Weight Value')
    plt.title('Comparison of True and Learned Weights')
    plt.legend()
    plt.show()

    # Display some loss values during training
    for index in range(0, len(plain_model.losses), 100):
        print(
            f'Iteration {index}: Plain SGD Loss = {plain_model.losses[index]:.4f}, Kalman SGD Loss = {kalman_model.losses[index]:.4f}')


main()
